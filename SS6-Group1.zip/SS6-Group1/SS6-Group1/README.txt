Project for CZ2002 - Object Oriented Design and Programming.

Console-based application of My STudent Automated Registration System (MySTARS)

Team Members:
CALVIN TAN JUN HAO
GUO FEIYAN
CHEAH MUN YAN, GRACE
TAN MEI XUAN
CHIA WEI QI, BELINDA

Instructions

1. Link to video demonstration of our application : https://www.youtube.com/watch?v=ZoDGWBh6MUI&feature=youtu.be

2. .jar file of the application can be identified as STARSFINAL.jar

3. The class and sequence diagrams can be found as image files in the project folder.

4. The passwords for the admin and student account have been hashed. However for the student accounts, we have 
   another .txt file (student_nothashed.txt) containing the unhashed passwords for demonstration and testing purposes.


Test Accounts for Admin and Student

(Admin Account)
Username : adminTim
Password : 123

(Student Account)
Username : MCHEAH004
Password : JELXkiNv





