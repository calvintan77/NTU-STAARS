	package ui;

import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

import javax.mail.internet.AddressException;

import controller.CalendarController;
import controller.CourseController;
import controller.StudentController;
import database.CourseDatabase;
import database.CourseRegDB;
import database.IndexDB;
import database.StudentDB;
import database.TimeSlotDB;
import database.WaitingListDB;

/**
 * The administrator interface of the stars system
 * @author CHEAH MUN YAN GRACE AND GUO FEIYAN
 * @version 1.0
 * @since 2020-11-18
 *
 */ 

public class AdminUI {
    /**
     * The main function of the administrator interface
     * @param args Contains the supplied command-line arguments as an array of String objects.
     * @throws IOException : thrown if there are issues with accessing the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object
     */ 
	public static void main(String[] args) throws IOException, AddressException, ParseException {
		int choice;
		Scanner sc = new Scanner(System.in);
		CourseRegDB.initCourseReg();
		StudentDB.initStudent();
		IndexDB.initIndex();
		TimeSlotDB.initTimeSlot();
		CourseDatabase.initCourse();
		
		do {
			System.out.println("\n==================================================");
			System.out.println("Welcome to admin access.");
			System.out.println("==================================================\n");
			System.out.println("Which function would you like to use?\n");
			System.out.println("(1): Add Student");
			System.out.println("(2): Edit Student Access Period");
			System.out.println("(3): Print Student by Index");
			System.out.println("(4): Print Student by Course");
			System.out.println("(5): Add Course");
			System.out.println("(6): Update Course");
			System.out.println("(7): Print Courses");
			System.out.println("(8): Logout");		
			
			choice = CourseController.choiceCheck(1,8);
			switch (choice)
			{
			case 1:
				StudentController.createStudent();
				break;
			case 2:
				CalendarController.editAccessTime();
				break;
			case 3:
				StudentController.printStudentByIndex();
				break;
			case 4:
				StudentController.printStudentByCourse();
				break;
			case 5: 
				CourseController.addCourse();
				break;
			case 6:
				CourseController.UpdateCourse();
				break;
			case 7:
				CourseController.printCourse();
				break;
			case 8:
				CourseRegDB.alr.clear();
				StudentDB.alr4.clear();
				CourseDatabase.alr3.clear();
				WaitingListDB.alr5.clear();
				TimeSlotDB.alr6.clear();
				IndexDB.alr2.clear();
				System.out.println("You have been successfully logged out!\n");
				MainUI.CallMainUI();
				break;
			}
		} while (choice < 9);
		
			
	}
	
    /**
     * Calls the administrator interface
     * @throws IOException : thrown if there are issues with accessing the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object 
     */
	public static void CallAdminUI() throws IOException, ParseException, AddressException
	{
		main(null);
	}
}