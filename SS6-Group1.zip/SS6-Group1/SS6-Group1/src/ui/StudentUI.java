package ui;

import java.io.IOException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.mail.internet.AddressException;

import controller.CourseController;
import controller.CourseRegController;
import controller.LoginController;
import database.CourseDatabase;
import database.CourseRegDB;
import database.IndexDB;
import database.StudentDB;
import database.TimeSlotDB;
import database.WaitingListDB;

/**
 * The student interface of the stars system
 * @author CALVIN TAN AND BELINDA CHIA
 * @version 1.0
 * @since 2020-11-18
 *
 */ 
public class StudentUI 
{	
    /**
     * The main function of the student interface
     * @param args Contains the supplied command-line arguments as an array of String objects.
     * @throws IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object
     */
	public static void main(String[] args) throws IOException, AddressException, ParseException
	{
		CourseRegDB.initCourseReg();
		StudentDB.initStudent();
		CourseDatabase.initCourse();
		IndexDB.initIndex();
		WaitingListDB.initWaitingList();
		TimeSlotDB.initTimeSlot();

		int choice;
		Scanner sc = new Scanner(System.in);		

		do {
			System.out.println("\n==================================================");
			System.out.println("Welcome to student access");
			System.out.println("==================================================\n");
			System.out.println("Current student user: " + getName());
			System.out.println("\n**********Your access period is from " + getStartTime() + " to " + getEndTime()+"**********\n");
			System.out.println("Which function would you like to use?");
			System.out.println("(1): Add Course");
			System.out.println("(2): Drop Course");
			System.out.println("(3): Check/Print Courses Registered");
			System.out.println("(4): View List Of Courses");
			System.out.println("(5): Check Vacancies Available");
			System.out.println("(6): Change Index Number of Course");
			System.out.println("(7): Swap Index Number with Another Student");
			System.out.println("(8): Logout");		
			choice = CourseController.choiceCheck(1,8);

			switch (choice)
			{			
			case 1:
				CourseRegController.addCourse();
				break;
			case 2:
				CourseRegController.dropCourse();
				break;
			case 3:
				CourseRegController.registeredCourses();
				break;
			case 4:
				CourseRegController.printCourse();
				break;
			case 5:
				CourseRegController.checkVacancies();
				break;
			case 6: 
				CourseRegController.ChangeIndex();
				break;
			case 7:
				CourseRegController.SwapIndex();
				break;
			case 8:
				CourseRegDB.alr.clear();
				StudentDB.alr4.clear();
				CourseDatabase.alr3.clear();
				WaitingListDB.alr5.clear();
				TimeSlotDB.alr6.clear();
				IndexDB.alr2.clear();
				System.out.println("You have been successfully logged out!\n");
				MainUI.CallMainUI();
				break;
			}
		} while (choice < 9);
	}
	
    /**
     * Calls the student interface
     * @throws IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object 
     */
	public static void CallStudentUI() throws IOException, AddressException, ParseException
	{
		main(null);
	}
	
    /**
     * Gets the name of the logged in student
     * @throws IOException : thrown if there are issues with reading from the database
     * @return returns the name of the logged in user
     */
	public static String getName() throws IOException
	{
		String Name =  "";
		String matric = LoginController.matric();
		for (int i = 0; i < StudentDB.alr4.size(); i++) 
		{
			if (matric.equals(StudentDB.alr4.get(i).getMatric()))
			{
			    Name = StudentDB.alr4.get(i).getName();
			}
		}
		return Name;
	}
	
	 /**
     * Gets the start of the access time of the logged in student
     * @throws IOException : thrown if there are issues with reading from the database
     * @return returns the starting access time of the logged in user
     */
	public static String getStartTime() throws IOException
	{
		String start =  "";
		String matric = LoginController.matric();
		for (int i = 0; i < StudentDB.alr4.size(); i++) 
		{
			if (matric.equals(StudentDB.alr4.get(i).getMatric()))
			{
			    start = StudentDB.alr4.get(i).getAccessStart();
			    
			}
		}
		return start;
	}
    /**
     * Gets the end of the access time of the logged in student
     * @throws IOException : thrown if there are issues with reading from the database
     * @return returns the ending access time of the logged in user
     */
	public static String getEndTime() throws IOException
	{
		String end =  "";
		String matric = LoginController.matric();
		for (int i = 0; i < StudentDB.alr4.size(); i++) 
		{
			if (matric.equals(StudentDB.alr4.get(i).getMatric()))
			{
			    end = StudentDB.alr4.get(i).getAccessEnd();
			    
			}
		}
		return end;
	}
	
}