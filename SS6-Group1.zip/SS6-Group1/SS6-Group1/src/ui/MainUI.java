package ui;

import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

import javax.mail.internet.AddressException;

import controller.LoginController;

/**
 * The main interface of the stars system which displays the login page
 * @author CALVIN TAN AND CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-18
 *
 */ 

public class MainUI {
    
    /**
     * Scanner object to parse primitive types and strings using regular expressions
 */
	static Scanner sc = new Scanner(System.in);


    /**
     * The main function of the main interface
     * @param args Contains the supplied command-line arguments as an array of String objects.
     * @throws IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object
     */ 
	public static void main(String[] args) throws IOException, AddressException, ParseException {
		LoginController.LoginOption();
		
	}
	
    /**
     * Displays the login page
     * @return returns the access right of the student (Admin/Student)
     */
	public static String domainUI() {
		String accessRight = "";
		int choice = 0;
		System.out.println("==================================================");
		System.out.println("   _____   ______  ___      ____    _____");
		System.out.println("  / ___/  /_  __/ /   |    / __ \\  / ___/");
		System.out.println("  \\__ \\    / /   / /| |   / /_/ /  \\__ \\");
		System.out.println(" ___/ /   / /   / ___ |  / _  _/  ___/ /");
		System.out.println("/____/   /_/   /_/  |_| /_/ |_|  /____/");
		System.out.println("");
		System.out.println("==================================================\n");
		domainLoop:
		while(true){
			System.out.println("********Select Domain********");
			System.out.println("(1) Student");
			System.out.println("(2) Admin");
			System.out.println("(3) Quit");
			System.out.print("> ");
			try {
				choice = Integer.parseInt(sc.nextLine());
				switch (choice) {
				case 1:
					accessRight = "STUDENT";
					break domainLoop;
				case 2:
					accessRight = "ADMIN";
					break domainLoop;
				case 3:
					System.out.println("System terminated.");
					System.exit(0);
				default:
					System.out.println("Invalid Input! Please re-enter!");
					System.out.println();
				}
			} catch (Exception e) {
				System.out.println("Invalid Input! Please re-enter!");
				System.out.println();
			}
		}
		return accessRight;
	}
	
    /**
     * Calls the main interface
     * @throws IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object 
     */
	public static void CallMainUI() throws IOException, AddressException, ParseException 
	{
		main(null);
	}
}
