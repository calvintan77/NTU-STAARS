package controller;

import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import database.CourseDatabase;
import database.CourseRegDB;
import database.IndexDB;
import database.StudentDB;
import entity.Student;
import controller.CheckController;

/**
 * A manager to handle all students related tasks
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-21
 */
public class StudentController extends CheckController {
	/**
	 * file directory for the Student text file
	 */
	public static String filename = "student.txt";
	/**
	 * file directory for the Student text file without hashed password used for testing purposes
	 */
	public static String filename2 = "student_nothashed.txt";
	/**
	 * separator to manipulate text files
	 */
	public static final String SEPARATOR = "|";

	/**
	 * Add new students 
	 * @throws IOException thrown if there are issues with reading the text files
	 */
	public static void createStudent() throws IOException {

		String username = "";
		String password = "";
		String name = "";
		String matric = "";
		String gender = "";
		String nationality = "";
		String school = "";
		String email = "";
		String accessStart = "ACCESSSTART";
		String accessEnd = "ACCESSEND";

		Scanner sc = new Scanner(System.in);
		String adminSelection = "";

		// to be used for data validation
		String alpha = "[a-zA-Z.*\\s+.]+";
		String alphanum = "^[a-zA-Z0-9]*$";

		// Prompt administrator for student details and set it into a Student object
		do {
			Student s = new Student();
			Student student = new Student();
			Student check = new Student();

			System.out.println("\n==================================================");
			System.out.println("Add a new student ");
			System.out.println("==================================================\n");

			// students start and end access times are unknown when creating a new student
			s.setAccessStart(accessStart);
			s.setAccessEnd(accessEnd);
			student.setAccessEnd(accessEnd);
			student.setAccessStart(accessStart);


			// get student name
			do {
				System.out.print("Please enter student's name: ");
				name = sc.nextLine();
				
				// check for blank or non-alphabetic inputs
				if (name.equals("") || !name.matches(alpha)) {
					System.out.println("Please enter valid name!\n");
				} else {
					s.setName(name.toUpperCase());
					student.setName(name.toUpperCase());
				}
			} while (name.equals("") || !name.matches(alpha));
			
			// set student's user name
			do {
				System.out.print("\nPlease enter student's username: ");
				username = sc.nextLine();
				s.setUsername(username.toUpperCase());
				// check if user name already exists
				check = retrieveStudentByUsername(s);
				
				// check for blank or non-alphabetic or non numerical inputs
				if (username.equals("") || !username.matches(alphanum))
				{
					System.out.println("Please enter a valid username!");
				}
				else if (check != null)
				{
					System.out.println("Username already exists. Please enter a new username!");
				}
				else {
					s.setUsername(username.toUpperCase());
					student.setUsername(username.toUpperCase());
				}
				
			} while (username.equals("") || !username.matches(alphanum) || check != null);
			
			// set password
			do {
				final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				SecureRandom random = new SecureRandom();
				StringBuilder sb = new StringBuilder();
				
				// random password is created for the student
				for (int i = 0; i < 8; i++) {
					int randomIndex = random.nextInt(chars.length());
					sb.append(chars.charAt(randomIndex));
				}
				
				// to append to the non_hashed file for testing purposes
				password = sb.toString();
				student.setPassword(password);
				
				// student's password is hashed
				String Hashedpw = getSecurePassword(password);
				s.setPassword(Hashedpw);
				System.out.println("\nStudent's Password has been randomly generated.");
			} while (password.equals(""));

			// get student matriculation number
			do {
				System.out.print("\nPlease enter student's matriculation number: ");
				matric = sc.nextLine().toUpperCase();

				// check if matriculation number already exists
				s.setMatric(matric);
				check = retrieveStudent(s);
				if (matric.equals("") || !matric.matches(alphanum) || !matric.startsWith("U")) {
					System.out.println("Please enter a valid matriculation number! Input should be alphanumeric and start with U.");
				} 
				else if (matric.length() != 9){
					System.out.println("Matriculation number should be 9 characters long!");
				}
				else if (check != null) {
					System.out.println("Student already exists. Please enter a new matriculation number!");
				} else {
					s.setMatric(matric.toUpperCase());
					student.setMatric(matric.toUpperCase());
				}
			} while (matric.equals("") || !matric.matches(alphanum) || !matric.startsWith("U") || matric.length() != 9 || (check != null));

			// get student's gender
			do {
				System.out.print("\nPlease enter student's gender (Female/Male): ");
				gender = sc.nextLine();
				
				// ensure that gender put is either female or male
				if (!gender.equals("Female") && !gender.equals("female") && !gender.equals("Male")
						&& !gender.equals("male")) {
					System.out.println("Please enter a valid gender!");
				} else {
					s.setGender(gender.toUpperCase());
					student.setGender(gender.toUpperCase());
				}
			} while (!gender.equals("Female") && !gender.equals("female") && !gender.equals("Male")
					&& !gender.equals("male"));

			// get student's nationality
			do {
				System.out.print("\nPlease enter student's nationality: ");
				nationality = sc.nextLine();

				if (nationality.equals("") || !nationality.matches(alpha)) {
					System.out.println("Please enter a valid nationality!");
				} else {
					s.setNationality(nationality.toUpperCase());
					student.setNationality(nationality.toUpperCase());
				}
			} while (nationality.equals("") || !nationality.matches(alpha));

			// get student's school
			do {
				System.out.print("\nPlease enter student's school: ");
				school = sc.nextLine();

				if (school.equals("") || !school.matches(alpha)) {
					System.out.println("Please enter a valid school!");
				} else {
					s.setSchool(school.toUpperCase());
					student.setSchool(school.toUpperCase());
				}
			} while (school.equals("") || !school.matches(alpha));

			// get student's email
			do {
				System.out.print("\nPlease enter student's email: ");
				email = sc.nextLine().toUpperCase();
				s.setEmail(email);
				check = retrieveStudentByEmail(s);
				if (email.equals("")) {
					System.out.println("Please enter a valid email!");
				} 
				else if (check != null) {
					System.out.println("This email already exists! Please enter a new email.");
				}
				else {
					s.setEmail(email);
					student.setEmail(email);
				}
			} while (email.equals("") || (check)!= null);
			
			
			StudentDB studentDB = new StudentDB();
			StudentDB studDB = new StudentDB();
			StudentDB.alr4.clear();
			// to write student data into student.txt
			ArrayList al = studentDB.readStudent(filename);	
			al.add(s);
			studentDB.save(filename, al);
			al.clear();
			
			// to write student data with non_hashed password into student_nothashed.txt
			ArrayList al2 = studDB.readStudent(filename2);
			al2.add(student);
			studDB.save(filename2, al2);
			al2.clear();

			// ensure that student is found in the text file database

		    System.out.println("You have successfully added a new student!");

			
			
			// to allow the option of adding more students at one go
			do {
				System.out.println("\nDo you want to continue? ");
				System.out.println("(1): Yes");
				System.out.println("(2): No");
				adminSelection = sc.nextLine();

				if ((!adminSelection.equals("1")) && (!adminSelection.equals("2"))) {
					System.out.println("Please enter a valid option\n");
				}

			} while ((!adminSelection.equals("1")) && (!adminSelection.equals("2")));
			
		} while (adminSelection.equals("1"));
		
		printStudentList();
	
	}

	/**
	 * To check if student with specific matriculation number already exists
	 * @param s The Student Object with the specific matriculation number
	 * @return the student if it exists, else return null
	 */
	public static Student retrieveStudent(Student s) {

		for (int i = 0; i < StudentDB.alr4.size(); i++) {
			Student searchStudent = (Student) StudentDB.alr4.get(i);

			if (s.getMatric().equals(searchStudent.getMatric())) {
				return searchStudent;
			}
		}
		return null;
	}
	
	/**
	 * Check if student with a specific user name already exists
	 * @param s Student Object with the specific user name
	 * @return the student if it exists, else return null
	 * @throws IOException if there are issues with initializing the database
	 */
	public static Student retrieveStudentByUsername(Student s) throws IOException {
		StudentDB.initStudent();
		for (int i = 0; i < StudentDB.alr4.size(); i++)
		{
			Student searchStudent = (Student) StudentDB.alr4.get(i);
			
			if (s.getUsername().equals(searchStudent.getUsername()))
				return searchStudent;
		}
		return null;
	}
	
	public static Student retrieveStudentByEmail(Student s) {
		for (int i = 0; i < StudentDB.alr4.size(); i++)
		{
			Student searchStudent = (Student) StudentDB.alr4.get(i);
			
			if (s.getEmail().equals(searchStudent.getEmail()))
				return searchStudent;
		}
		return null;
	}
	
	// 
	/**
	 * To retrieve all students information from database
	 * @return array of students retrieved from the database
	 */
	public static ArrayList retrieveAllStudentFromDb() {
		ArrayList alr = new ArrayList();
		alr = null;

		try {
			StudentDB studentDB = new StudentDB();
			alr = studentDB.readStudent(filename);
		} catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		return alr;
	}

	/**
	 * Update the access time period for each student
	 * @param matric Student Object's matriculation number
	 * @param newAccessStart The start of Student Object's new Access Time Period
	 * @param newAccessEnd The end of Student Object's new Access Time Period
	 */
	public static void updateAccessPeriod(String matric, String newAccessStart, String newAccessEnd) {
		Student student = new Student();
		student.setMatric(matric.toUpperCase());
		Student checkStudent = new Student();
		checkStudent = retrieveStudent(student);

		if (checkStudent != null) {
			checkStudent.setAccessStart(newAccessStart);
			checkStudent.setAccessEnd(newAccessEnd);
		}

		// save student details
		try {
			for (int i = 0; i < StudentDB.alr4.size(); i++) {
				Student searchStudent = (Student) StudentDB.alr4.get(i);
				if (checkStudent.getMatric().equals(searchStudent.getMatric())) {
					StudentDB.alr4.set(i, checkStudent);
				}
			}

			StudentDB studentDB = new StudentDB();
			studentDB.save(filename, StudentDB.alr4);
			System.out.println("\nYou have successfully updated the student's access time period!\n");
		} catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	
	/**
	 * Hashing of student's account password
	 * @param passwordToHash Student Object's password
	 * @return the encrypted password of the Student Object
	 */
	public static String getSecurePassword(String passwordToHash) {
		String HashedPassword = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			HashedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return HashedPassword;
	}
	
	/**
	 * Print all the students in the database 
	 * @throws IOException thrown if there are issues with retrieving the Student database
	 */
	public static void printStudentList() throws IOException {
		StudentDB.initStudent();
		System.out.println("==================================================");
		System.out.println("List of current students");
		System.out.println("==================================================\n");
		System.out.println("Index	  Name	      Matriculation Number");
		System.out.print("==================================================\n");

		for (int i = 0; i < StudentDB.alr4.size(); i++) {
			System.out.printf("%-10s", i+1);
			System.out.printf("%-15s", StudentDB.alr4.get(i).getName());
			System.out.printf("%-15s \n", StudentDB.alr4.get(i).getMatric());
		}
	}
	
	/**
	 * Print student list by course
	 */
	public static void printStudentByCourse() {
	    Scanner sc = new Scanner(System.in);
	    boolean check = false;
	    boolean flag = false;
	    System.out.println("\n==================================================");
	    System.out.println("Print Student by Course");
	    System.out.println("==================================================\n");
	    System.out.print("Which course would you like to look at? ");
	    String course = sc.nextLine().toUpperCase();
	         
	    System.out.println("\nNAME           GENDER         NATIONALITY");    
	    System.out.println("=========================================");
	     if (isCourseValid(course))
	     {
	         flag = true; 
	     }

	      for (int k = 0; k < CourseRegDB.alr.size(); k ++)
	      {
	        if (course.equals(CourseRegDB.alr.get(k).getcourseCode()))
	        {
	          for (int j = 0; j < StudentDB.alr4.size(); j++)
	          {
	            if (CourseRegDB.alr.get(k).getmatric().equals(StudentDB.alr4.get(j).getMatric()))
	            {
	              System.out.printf("%-15s", StudentDB.alr4.get(j).getName());
	              System.out.printf("%-15s", StudentDB.alr4.get(j).getGender());
	              System.out.printf("%-15s \n", StudentDB.alr4.get(j).getNationality());
	              check = true;
	            }     
	          }
	        }
	      }

	      if (check == false && flag == true) {
	        System.out.println("");
	        System.out.println("There are no students registered in this course!");
	      }
	      if (flag == false && check == false) {
	        System.out.println("\nThis course does not exist");
	      }
	  }
	  
	/**
	 * Print student list by course's index
	 */
	public static void printStudentByIndex() {
		Scanner sc = new Scanner(System.in);
		boolean flag = false;
		boolean check = false;
		int index = -1;

		System.out.println("\n==================================================");
		System.out.println("Print Student by Index");
		System.out.println("==================================================\n");

		while (true) {
			System.out.print("Which Index would you like to look at? ");
			String input = sc.next();
			try {
				index = Integer.parseInt(input);
				break;
			} catch (NumberFormatException ne) {
				System.out.println("Please input an integer value!\n");
			}
		}
	    System.out.println("\nNAME           GENDER         NATIONALITY");    
	    System.out.println("=========================================");
	      if (isIndexExists(index))
	      {  
	        flag = true;    
	      }
	      
	      for (int k = 0; k < CourseRegDB.alr.size(); k ++)
	      {
	        if (index==CourseRegDB.alr.get(k).getindex())
	        {
	          for (int j = 0; j < StudentDB.alr4.size(); j++)
	          {
	            if (CourseRegDB.alr.get(k).getmatric().equals(StudentDB.alr4.get(j).getMatric()))
	            {
	              System.out.printf("%-15s", StudentDB.alr4.get(j).getName());
	              System.out.printf("%-15s", StudentDB.alr4.get(j).getGender());
	              System.out.printf("%-15s \n", StudentDB.alr4.get(j).getNationality());
	              check = true;
	            }     
	          }
	        }
	      }

	      if (check == false && flag == true) {
	        System.out.println("");
	        System.out.println("There are no students registered in this index!");
	      }
	      if (flag == false && check == false) {
	        System.out.println("\nThis index does not exist");
	      }
	  }
	}