package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import database.TimeSlotDB;
import entity.TimeSlot;

/**
 * Manager to handle all lesson time slot related tasks
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-21
 */
public class TimeSlotController {
	/**
	 * Add the time slots for each course index
	 * @param ts The time slot
	 */
	public static void addTimeslot(TimeSlot ts) {
		try {
			ArrayList newTimeslot = new ArrayList();
			newTimeslot.add(ts);
			TimeSlotDB.saveTimeslots("timeslot.txt",newTimeslot);
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	/**
	 * Record the day of each lesson
	 * @param m counter value
	 * @return The day of this lesson
	 */
	public static int typeCheck(int m) {
		Scanner sc = new Scanner(System.in);
		int type1_3 = 0;
		while (true) {
			System.out.printf("\nEnter Type of the lesson (Lesson %d):\n", m+1); 
			System.out.println("1 = Tutorial, 2 = Lecture, 3 = Laboratory");
            String input = sc.next();
            try {
            	type1_3 = Integer.parseInt(input);
                if(type1_3 < 1 || type1_3 > 3) {
                	System.out.println("This is not a number from 1 to 3");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("This is not a number.");
            }
        }
		return type1_3;
	}
	/**
	 * Method called after typeCheck() to quantify the user input on the type of the lesson
	 * @param type1_3 User choice of 1 to 3, each representing a type
	 * @return The type of the lesson
	 */
	public static String getType(int type1_3) {
		String type="";
		switch(type1_3) {
		case 1:
			type = "TUT";
			break;
		case 2:
			type = "LEC";
			break;
		case 3:
			type = "LAB";
			break;
		}
		return type;
	}
	/**
	 * Add venues for lessons specifically to the course index
	 * @param day The day of the lesson
	 * @param start The start time of the lesson
	 * @param end The end time of the lesson
	 * @return The Venue of the lesson
	 */
	public static String checkVenue(String day, String start, String end) {
		Scanner sc = new Scanner(System.in);
		
		int Start = Integer.parseInt(start);
		int End = Integer.parseInt(end);
		String venue = "";
		try {
			ArrayList current = TimeSlotDB.readTimeslots("timeslot.txt");
			while(true) {
				boolean check = true;
				System.out.print("\nEnter Venue of the lesson: ");
				venue = sc.next().toUpperCase();
				for (int i=0 ; i<current.size() ; i++) {
					TimeSlot ts = (TimeSlot)current.get(i);
					String dayOfWeek = ts.getdayOfweek();
					int startTime = Integer.parseInt(ts.getstartTime());
					int endTime = Integer.parseInt(ts.getendTime());
					if(day.equals(dayOfWeek)) {
					if(startTime <= Start && endTime > Start) {
							if(ts.getvenue().equals(venue)) {
								System.out.println("Error: Venue already taken for the current timeslot.");
								check = false;
								break;
							}
						}
						if(startTime < End && endTime >= End) {
							if(ts.getvenue().equals(venue)) {
								System.out.println("Error: Venue already taken for the current timeslot.");
								check = false;
								break;
							}
						}
					}
				}
				if(check) {
					return venue;
				}
				continue;
			}
			}catch (IOException e) {
				System.out.println("IOException > " + e.getMessage());
		
			}
		return venue;
	}
	/**
	 * Record the day of each lesson
	 * @return The day of this lesson
	 */
	public static int dayCheck() {
		Scanner sc = new Scanner(System.in);
		int day1_7 = 0;
		while (true) {
			System.out.print("\nEnter Day of the lesson(1-7), 1 = MONDAY etc... :");
            String input = sc.next();
            try {
                day1_7 = Integer.parseInt(input);
                if(day1_7 < 1 || day1_7 > 7) {
                	System.out.println("This is not a number from 1 to 7");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("This is not a number.");
            }
        }
		return day1_7;
	}
	/**
	 * Method called after dayCheck() to quantify the user input on the day of the lesson
	 * @param day1_7 User choice of 1 to 7, each representing a day
	 * @return The day of the lesson
	 */
	public static String getDay(int day1_7) {
		String day="";
		switch(day1_7) {
		case 1:
			day = "MON";
			break;
		case 2:
			day = "TUE";
			break;
		case 3:
			day = "WED";
			break;
		case 4:
			day = "THU";
			break;
		case 5:
			day = "FRI";
			break;
		case 6:
			day = "SAT";
			break;
		case 7:
			day = "SUN";
			break;
		}
		return day;
	}
	/**
	 * Record the start time of the lesson
	 * @return the start time of this lesson
	 */
	public static String STimeCheck() {
		Scanner sc = new Scanner(System.in);
		int time = 0;
		while (true) {
			System.out.print("\nEnter Start time in 24-hr format: ");
            String input = sc.next();
            try {
                time = Integer.parseInt(input);
                if(time/100 < 8 || time/100 >18 || time%100<0 || time%100>59) {
                	System.out.println("Error: Start time must be between 0830 to 1830.");
                	continue;
                }
                else if(time/100 == 8 && (time%100<30||time%100>59)) {
                	System.out.println("Error: Start time must be between 0830 to 1830.");
                	continue;
                }
                else if(time/100 == 18 && (time%100<0||time%100>30)) {
                	System.out.println("Error: Start time must be between 0830 to 1830.");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
            }
        }
		String Time = "";
		if(time > 999) {
			Time = String.valueOf(time);
			return Time;
		}
		else if (time > 99) {
			Time = "0" + String.valueOf(time);
			return Time;
		}
		else if (time > 9) {
			Time = "00" + String.valueOf(time);
			return Time;
		}
		else if (time >= 0) {
			Time = "000" + String.valueOf(time);
			return Time;
		}
		return Time;
	}
	/**
	 * Record the end time of the lesson
	 * @param startTime The start time of this lesson
	 * @return the end time of this lesson
	 */
	public static String ETimeCheck(String startTime) {
		Scanner sc = new Scanner(System.in);
		int time = 0;
		int starttime = Integer.parseInt(startTime);
		while (true) {
			System.out.print("\nEnter End time in 24-hr format: ");
            String input = sc.next();
            try {
                time = Integer.parseInt(input);
                if(time/100 < 8 || time/100 >18 || time%100<0 || time%100>59) {
                	System.out.println("Error: End time must be between 0830 to 1830.");
                	continue;
                }
                else if(time/100 == 8 && (time%100<30||time%100>59)) {
                	System.out.println("Error: End time must be between 0830 to 1830.");
                	continue;
                }
                else if(time/100 == 18 && (time%100<0||time%100>30)) {
                	System.out.println("Error: End time must be between 0830 to 1830.");
                	continue;
                }
                else if(time<=starttime){
                	System.out.println("Error: End time must be after start time.");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
            }
		}
		String Time = "";
		if(time > 999) {
			Time = String.valueOf(time);
			return Time;
		}
		else if (time > 99) {
			Time = "0" + String.valueOf(time);
			return Time;
		}
		else if (time > 9) {
			Time = "00" + String.valueOf(time);
			return Time;
		}
		else if (time >= 0) {
			Time = "000" + String.valueOf(time);
			return Time;
		}
		return Time;
	}

	public static String startCheck(int index, String day) {
		Scanner sc = new Scanner(System.in);
		String start = "";
		int Start = -1;
		try {
			ArrayList current = TimeSlotDB.readTimeslots("timeslot.txt");
			while(true) {
				boolean check = true;
				start = STimeCheck();
				Start = Integer.parseInt(start);
				for (int i=0 ; i<current.size() ; i++) {
					TimeSlot ts = (TimeSlot)current.get(i);
					String dayOfWeek = ts.getdayOfweek();
					int startTime = Integer.parseInt(ts.getstartTime());
					int endTime = Integer.parseInt(ts.getendTime());
					int Index = ts.getindexNumber();
					if(index == Index && dayOfWeek.equals(day)) {
					if(startTime <= Start && endTime > Start) {
							System.out.println("Error: Timeslot clashed with a another timeslot.");
							check = false;
							break;
						
						}	
					}
				}
				if(check) {
					return start;
				}
				continue;
			}
			}catch (IOException e) {
				System.out.println("IOException > " + e.getMessage());
		
			}
		return start;
	}
	public static String endCheck(int index, String day, String start) {
		Scanner sc = new Scanner(System.in);
		String end = "";
		int End = -1;
		try {
			ArrayList current = TimeSlotDB.readTimeslots("timeslot.txt");
			while(true) {
				boolean check = true;
				end = ETimeCheck(start);
				End = Integer.parseInt(end);
				for (int i=0 ; i<current.size() ; i++) {
					TimeSlot ts = (TimeSlot)current.get(i);
					String dayOfWeek = ts.getdayOfweek();
					int startTime = Integer.parseInt(ts.getstartTime());
					int endTime = Integer.parseInt(ts.getendTime());
					int Index = ts.getindexNumber();
					if(index == Index && dayOfWeek.equals(day)) {
					if(startTime <= End && endTime > End) {
							System.out.println("Error: Timeslot clashed with a another timeslot.");
							check = false;
							break;
						
						}	
					}
				}
				if(check) {
					return end;
				}
				continue;
			}
			}catch (IOException e) {
				System.out.println("IOException > " + e.getMessage());
		
			}
		return end;
	}
}
