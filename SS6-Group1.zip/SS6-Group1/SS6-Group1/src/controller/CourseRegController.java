package controller;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.mail.internet.AddressException;

import database.CourseDatabase;
import database.IndexDB;
import database.StudentDB;
import database.CourseRegDB;
import database.WaitingListDB;
import database.TimeSlotDB;
import entity.CourseReg;
import entity.Student;
import entity.WaitingList;

/**
 * A manager to handle all course registration related tasks
 * @author CALVIN TAN AND BELINDA CHIA
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class CourseRegController extends CheckController
{
	/**
	 * file directory for CourseReg text file
	 */
	public static String filename = "CourseReg.txt";
	/**
	 * file directory for Index text file
	 */
	public static String filename1 = "index.txt";
	/**
	 * file directory for WaitingList text file
	 */
	public static String filename2 = "waitlist.txt";
	/**
	 * separator to manipulate text files
	 */
	public static final String SEPARATOR = "|";

	/**
	 * Registering a course for the student that is currently logged in
	 * @throws IOException : thrown if there are issues with updating the database
	 * @throws InputMismatchException : thrown is user input does not match the required input type (eg. inputting a string for an integer input)
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */
	public static void addCourse() throws IOException, InputMismatchException, AddressException
	{
		String matric = LoginController.matric();
		String courseCode;
		int index=0;
		int choice=0;
		int choice1 = 0;
		Scanner sc = new Scanner(System.in);
		boolean flag = false;
		CourseReg c = new CourseReg();
		WaitingList w = new WaitingList();			
		System.out.println("\n==================================================");
		System.out.println(" Add a new course ");
		System.out.println("==================================================");
		c.setmatric(matric);    
		System.out.println("\nYour current total AUs are: " + getAUs(matric));

		do {
			System.out.print("\nEnter Course Code to Add: ");
			courseCode = sc.nextLine().toUpperCase();

			if (flag = !checkRegistration(courseCode,matric)) {
				if(flag = isCourseValid(courseCode) ){
					c.setcourseCode(courseCode);
					flag = true;				
					break;
				}
				if (!flag) {
					System.out.println("Course does not exist in NTU!");						
				}
			}
		}while (!flag);

		for (int j = 0; j < CourseDatabase.alr3.size(); j++){
			if(courseCode.equals(CourseDatabase.alr3.get(j).getcourseCode())){
				int NewAU = CourseDatabase.alr3.get(j).getAu();
				int TotalAU = getAUs(matric)+NewAU;
				if (TotalAU>21){
					System.out.println("You cannot register for this course as you will exceed the AU Limit of 21");
					flag = false;
				}
				if (TotalAU<=21){
					continue;
				}
			}
			if (!flag){
				return;
			}
		}

		System.out.println("\nThe indexes and vacancies for " + courseCode + " are: \n");
		System.out.println("Index\tVacancy\t\tWaitlist Count");	
		System.out.println("==================================================");

		for (int i = 0; i < IndexDB.alr2.size(); i++){
			if (courseCode.equals(IndexDB.alr2.get(i).getcourseCode())){
				System.out.println(IndexDB.alr2.get(i).getindexNumber() + "\t" + IndexDB.alr2.get(i).getvacancy() +"/" + getClassSize(IndexDB.alr2.get(i).getindexNumber())+ "\t\t" + getWaitlistCount(IndexDB.alr2.get(i).getindexNumber()));
			}
		}					
		do {
			boolean check=false; 
			do {
				check = false;
				System.out.print("\nPlease enter index number that you want to register for: ");
				try {
					index = sc.nextInt();
					if (!checkIndexinCourse(courseCode, index)) {
						System.out.println("Invalid index number. Please enter again.");
					}
					else if (checkClash(index) == true){
						check = true;
					}
					else {
						do {
							System.out.println("\nDo you want to enter another index?");
							System.out.println("(1): Confirm");
							System.out.println("(2): Exit");
							choice = sc.nextInt();
							if (choice==1){
								break;
							}
							else if (choice==2){
								return;
							}
							else if (choice!=1|choice!=2)
							{
								System.out.println("Please enter a valid option (1 or 2)!");
							}
						}while(choice!=1|choice!=2);
					}
				} catch (InputMismatchException e) { 
					System.out.println("Please input integer only");
					sc.next();
					check = false;
				}
			}while (!check|!checkIndexinCourse(courseCode, index));	

			if(checkClash(index) == true)	{
					int sum=getWaitlistCount(index);
					int sum2=getVacancy(index);
					System.out.println("\n"+"Information about index "+index);
					System.out.println("\nType"+"\t" + "Day" + "\t" + "Start" + "\t" + "End" + "\t" + "Venue");
					for (int j = 0; j < TimeSlotDB.alr6.size(); j++){
						if (index==(TimeSlotDB.alr6.get(j).getindexNumber())){
							System.out.println(TimeSlotDB.alr6.get(j).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(j).getdayOfweek()+"\t"+TimeSlotDB.alr6.get(j).getstartTime()+"\t"+TimeSlotDB.alr6.get(j).getendTime()+"\t"+TimeSlotDB.alr6.get(j).getvenue());
						}
					}
					if (sum>5){
						System.out.println("\nIndex is severely oversubscribed! Please do not select this index to avoid any disappointments!");
					}
					if ((sum>=1 & sum<5)|sum2==0){
						System.out.println("\nIndex is oversubscribed! There is a chance you might not get this index!");
					}
					if (sum==0 && sum2>1){
						System.out.println("\nIndex is not oversubscribed!");
					} 
					do{
					System.out.println("\nConfirm to register for the index?");
					System.out.println("(1): Confirm");
					System.out.println("(2): Exit");
					choice = sc.nextInt();
					if (choice1==1){
						break;
					}
					else if (choice1==2){
						return;
					}
					else if (choice1!=1|choice1!=2) {
						System.out.println("Please enter a valid option (1 or 2)!");
					}
				} while (choice1!=1|choice1!=2);

				if (checkIndexinCourse(courseCode,index) == true){
					for (int i = 0; i < IndexDB.alr2.size(); i++){
						if (index == IndexDB.alr2.get(i).getindexNumber()){
							if (IndexDB.alr2.get(i).getvacancy()!=0){
								c.setindex(index);
								flag = true;                       	
								break;
							}         			
							if (IndexDB.alr2.get(i).getvacancy()==0){
								if (!IsRecordInWaitList(matric,index)){
									w.setindex(index);
									w.setmatric(matric);
									System.out.println("Index has no vacancy left. You are placed on the waiting list."); 
									// get student information based on matric and send the email
									Student checkStud = new Student();
									Student s = new Student();
									s.setMatric(matric);
									checkStud = StudentController.retrieveStudent(s);
									String email = checkStud.getEmail();
									String name = checkStud.getName();
									MailController.SendWaitingListMail(email, index, courseCode, name);
									flag = true;
									WaitingListDB.alr5.add(w);
									WaitingListDB.save(filename2, WaitingListDB.alr5);
									return;
								}
								else if (IsRecordInWaitList(matric,index)){
									System.out.println("You are already on the Waiting List of Index "+index+"!");
									return;
								}
							}
						}
					}
				}
				if (checkIndexinCourse(courseCode,index) == false){
					flag=false;
				}

				if (!flag){
					System.out.println("Invalid Index. Please enter again.\n");
				}	
			}
		}while (!flag);

		for (int i = 0; i < IndexDB.alr2.size(); i++) 
			if (IndexDB.alr2.get(i).getindexNumber() == index){
				IndexDB.alr2.get(i).setvacancy(IndexDB.alr2.get(i).getvacancy()-1);
			}
		IndexDB indexDB2 = new IndexDB();
		indexDB2.updateIndexes(filename1, IndexDB.alr2);
		CourseRegDB.alr.add(c);		
		CourseRegDB.save(filename, CourseRegDB.alr);
		System.out.println("You have successfully registered for the course: " + courseCode);
	}
	
	/**
	 * Changing index number for the student that is currently logged in
	 * @throws IOException : thrown if there are issues with saving the CourseReg object into the database
	 * @throws InputMismatchException : thrown is user input does not match the required input type (eg. inputting a string for an integer input) 
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */
	public static void ChangeIndex() throws IOException, AddressException, InputMismatchException
	{
		String matric = LoginController.matric(); 
		Scanner sc = new Scanner(System.in);
		boolean check = false; 
		String courseCode = "";
		int index1 = 0;
		int index2 = 0;
		int choice = 0;
		int choice1 = 0;
		System.out.println("\n==================================================");
		System.out.println(" Change Index ");
		System.out.println("==================================================");
		do {
	    check = false;
		System.out.println("\nEnter the current index: ");
		try {
			index1 = sc.nextInt();
			} catch (InputMismatchException e) { 
					System.out.println("Please input integer only!");
					sc.next();
					check = true;
			}
		if (!isIndexExists(index1)){
			if (!check) {
        	System.out.println("Index does not exist! Please enter again.");
        	check = true;}
		}
		else if (!checkRegistrationIndex(index1,matric)){
        	System.out.println("You are not registered for this index! Please enter another index.");
        	check = true;
        }
        else{
        	check = false;
        }
		} while (check);
		   
		do {
		check = false;
        System.out.println("\nEnter the new index: ");
		try {
				index2 = sc.nextInt();
		} catch (InputMismatchException e) { 
				System.out.println("Please input integer only!");
				sc.next();
				check = true;
		}
		if (!isIndexExists(index2)){
			if (!check) {
			System.out.println("Index does not exist! Please enter again.");
			check = true;}
        }
		else if (!IndexesSameCourse(index1,index2)){
			System.out.println("The two indexes are from different courses! Please enter again.");
			check = true;
		}
		else if (index1 == index2){
			System.out.println("Error! The two indexes are the same. Please enter again.");
			check = true;
		}
		else if (checkChangeClash(index1, index2) == false){
			do {
				System.out.println("\nDo you want to enter another index?");
				System.out.println("(1): Confirm");
				System.out.println("(2): Exit");
				choice = sc.nextInt();
				if (choice==1){
					check=true;
					break;
				}
				else if (choice==2){
                    return;
				}
				else if (choice!=1|choice!=2){
					System.out.println("Please enter a valid option (1 or 2)!");
				}
			}while(choice!=1|choice!=2);
		}
        else{
        	check = false;}
		} while (check);
		
		System.out.println("\nCurrent Index: " + index1);
		System.out.println("Type"+"\t" + "Day" + "\t" + "Start" + "\t" + "End" + "\t" + "Venue");
		for (int i = 0; i < TimeSlotDB.alr6.size(); i++){
			if (index1==(TimeSlotDB.alr6.get(i).getindexNumber())){
				System.out.println(TimeSlotDB.alr6.get(i).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(i).getdayOfweek()+"\t"+TimeSlotDB.alr6.get(i).getstartTime()+"\t"+TimeSlotDB.alr6.get(i).getendTime()+"\t"+TimeSlotDB.alr6.get(i).getvenue());
			}
		}
		System.out.println("\n"+"New Index: "+ index2);
		System.out.println("Type"+"\t" + "Day" + "\t" + "Start" + "\t" + "End" + "\t" + "Venue");
		for (int j = 0; j < TimeSlotDB.alr6.size(); j++){
			if (index2==(TimeSlotDB.alr6.get(j).getindexNumber())){
				System.out.println(TimeSlotDB.alr6.get(j).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(j).getdayOfweek()+"\t"+TimeSlotDB.alr6.get(j).getstartTime()+"\t"+TimeSlotDB.alr6.get(j).getendTime()+"\t"+TimeSlotDB.alr6.get(j).getvenue());
			}
		}
		
		do {
			System.out.println("\nConfirm to change index number?");
			System.out.println("(1): Confirm");
			System.out.println("(2): Exit");
			choice = sc.nextInt();
			if (choice1==1){
				break;
			}
			else if (choice1==2){
				return;}
			else if (choice1!=1|choice1!=2) {
				System.out.println("Please enter a valid option (1 or 2)!");
			}
		}
		while(choice!=1|choice!=2);
		
		if (isVacancyZero(index2)){
			if (!IsRecordInWaitList(matric,index2)){
			Student checkStud = new Student();
			Student s = new Student();
			s.setMatric(matric);
			checkStud = StudentController.retrieveStudent(s);
			String email = checkStud.getEmail();
			String name = checkStud.getName();
			for (int i = 0; i < IndexDB.alr2.size(); i++){
				if (index2==IndexDB.alr2.get(i).getindexNumber()){
					courseCode = IndexDB.alr2.get(i).getcourseCode();
				}
			}
			MailController.SendWaitingListMail(email, index2, courseCode, name);
			WaitingList w = new WaitingList(); 
			w.setindex(index2);
			w.setmatric(matric);
			WaitingListDB.alr5.add(w);
			WaitingListDB.save(filename2, WaitingListDB.alr5);
			System.out.println("The new index has no vacancies! You will retain your current index and be put on the waitlist for the new index.");
			return;}
			else if (IsRecordInWaitList(matric,index2)){
				System.out.println("You are already on the Waiting List of Index "+index2+"!");
				return;}
		}
		
		else if (!isVacancyZero(index2)){
			if (isVacancyZero(index1)){
				checkWaitList(index1,"\\|");}
			for (int i = 0; i < CourseRegDB.alr.size(); i++){	
				if (matric.equals(CourseRegDB.alr.get(i).getmatric()) && index1 == CourseRegDB.alr.get(i).getindex()){
					CourseRegDB.alr.get(i).setindex(index2);
					CourseRegDB.save(filename, CourseRegDB.alr);
					break;
				}
			}
			for (int k = 0; k < IndexDB.alr2.size(); k++) {
				if (IndexDB.alr2.get(k).getindexNumber() == index1){
					if (!isIndexInWaitList(index1)){
					    IndexDB.alr2.get(k).setvacancy(IndexDB.alr2.get(k).getvacancy()+1);
					}
					else{
						break;
					}
				}
				if (IndexDB.alr2.get(k).getindexNumber() == index2){
					IndexDB.alr2.get(k).setvacancy(IndexDB.alr2.get(k).getvacancy()-1);
				}		
				IndexDB indexDB = new IndexDB();
				indexDB.updateIndexes(filename1, IndexDB.alr2);	
		    }
			}
		    for (int i = 0; i < WaitingListDB.alr5.size(); i++){
				if (matric.equals(WaitingListDB.alr5.get(i).getmatric()) && index2==WaitingListDB.alr5.get(i).getindex()){
					WaitingListDB.deleteWaitList(index2,matric);
				}
			}	
			System.out.println("You have successfully changed index from " + index1 + " to " + index2);
	    }
    

	/**
	 * Swapping index number with another student for the student that is currently logged in
	 * @throws IOException : thrown if there are issues with saving the CourseReg object into the database
	 * @throws InputMismatchException : thrown is user input does not match the required input type (eg. inputting a string for an integer input) 
	 */
	public static void SwapIndex() throws IOException, InputMismatchException
	{
		String matric = LoginController.matric(); 
		Scanner sc = new Scanner(System.in);
		String name = "";
		String courseCode = "";
		String matric2 = "";
		String username = "";
		String password = "";
		String notHashedpassword = "";
		int index1 = 0;
		int index2 = 0;
		int choice = 0;
		boolean check = false;
		String alphanum = "^[a-zA-Z0-9]*$";
		System.out.println("\n==================================================");
		System.out.println(" Swap Index ");
		System.out.println("==================================================\n");
		do {
			System.out.print("Please enter student 2's matriculation number: ");
			matric2 = sc.nextLine().toUpperCase();
			if (!IsMatricExists(matric2)){
				System.out.println("Matriculation number does not exist. Please enter again.");
				check = true;
			}
			else if (matric2.equals(matric)){
				System.out.println("Error! This is your matriculation number! Please enter again.");
				check = true;
			}
			else {
				check = false;
			}
		} while (check);
		
		do {
		    System.out.println("\nEnter the index that you want to swap: ");	
		    try {
			    index1 = sc.nextInt();
			    } catch (InputMismatchException e) { 
					System.out.println("Please input integer only!");
					sc.next();
					check = true;
			    }
	  	    if (!isIndexExists(index1)){
	  	    	if (!check) {
        	    System.out.println("Index does not exist! Please enter again.");
        	    check = true;}
		    }
	  	    else if (!checkRegistrationIndex(index1,matric)){
        	    System.out.println("You are not registered for this index! Please enter another index.");
        	    check = true;
            }
            else{
        	    check = false;
            }
		} while (check);
		
		do {
			check = false;
	        System.out.println("\nEnter person 2's index: ");
			try {
					index2 = sc.nextInt();
			} catch (InputMismatchException e) { 
					System.out.println("Please input integer only!");
					sc.next();
					check = true;
			}
			if (!isIndexExists(index2)){
				System.out.println("Index does not exist! Please enter again.");
				check = true;
	        }
			else if (!checkRegistrationIndex(index2,matric2)){
				if(!check) {
				System.out.println("The other student is not registered for this index! Please enter again.");
				check = true;}
			}
			else if (!IndexesSameCourse(index1,index2)){
				System.out.println("The two indexes are from different courses! Please enter again.");
				check = true;
			}
			else if (index1 == index2){
				System.out.println("Error! The two indexes are the same. Please enter again.");
				check = true;
			}
			else if (checkSwapClash(matric2, index1, index2) == false){
                System.out.println("You are not allowed to swap indexes with the other student!");
                return;
			}
	        else{
	        	check = false;}
		} while (check);
		
		do {   
			do {
			    System.out.println("\nPlease enter student 2's username: ");
			    username = sc.next();
			    if (username.equals("") || !username.matches(alphanum)){
				    System.out.print("Username cannot be null. Please enter again. \n");
			    }
		    } while (username.equals("") || !username.matches(alphanum));

		    do {
			    System.out.println("\nPlease enter student 2's password: ");
			    notHashedpassword = sc.next();
			    password = StudentController.getSecurePassword(notHashedpassword);
			    if (notHashedpassword.equals("") || !notHashedpassword.matches(alphanum)){
				    System.out.print("Password cannot be null. Please enter again. \n");
			    }
		    } while (notHashedpassword.equals("") || !notHashedpassword.matches(alphanum));

		    if (!verifyStudent2(username, password, "student.txt")){
			    System.out.print("\nInvalid Student 2's username or password. Please enter again. \n");
			    check = true;
		    }
		    else {
		    	check = false;
		    }
	    }while(check);
		
		courseCode = getCourseCodefromIndex(index1);
		System.out.println("\nCourse Code: " + courseCode);
		System.out.println("\nMatric1: " + matric + " Index Number 1: " + index1);
		System.out.println("Type"+"\t" + "Day" + "\t" + "Start" + "\t" + "End" + "\t" + "Venue");
		for (int i = 0; i < TimeSlotDB.alr6.size(); i++){
			if (index1==(TimeSlotDB.alr6.get(i).getindexNumber())){
				System.out.println(TimeSlotDB.alr6.get(i).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(i).getdayOfweek()+"\t"+TimeSlotDB.alr6.get(i).getstartTime()+"\t"+TimeSlotDB.alr6.get(i).getendTime()+"\t"+TimeSlotDB.alr6.get(i).getvenue());
			}
		}
		System.out.println("\nMatric2: " + matric2 + " Index Number 2: " + index2);
		System.out.println("Type"+"\t" + "Day" + "\t" + "Start" + "\t" + "End" + "\t" + "Venue");
		for (int j = 0; j < TimeSlotDB.alr6.size(); j++){
			if (index2==(TimeSlotDB.alr6.get(j).getindexNumber())){
				System.out.println(TimeSlotDB.alr6.get(j).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(j).getdayOfweek()+"\t"+TimeSlotDB.alr6.get(j).getstartTime()+"\t"+TimeSlotDB.alr6.get(j).getendTime()+"\t"+TimeSlotDB.alr6.get(j).getvenue());
			}
		}
		
		do {
			System.out.println("\nConfirm to swap index number?");
			System.out.println("(1): Confirm");
			System.out.println("(2): Exit");
			choice = sc.nextInt();
			if (choice==1){
				break;
			}
			else if (choice==2){
				return;}
			else if (choice!=1|choice!=2){
				System.out.println("Please enter a valid option (1 or 2)!");
			}
		}
		while(choice!=1|choice!=2);
		
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if (matric.equals(CourseRegDB.alr.get(i).getmatric()) && index1 == CourseRegDB.alr.get(i).getindex()){
				CourseRegDB.alr.get(i).setindex(index2);
			}
			if (matric2.equals(CourseRegDB.alr.get(i).getmatric()) && index2 == CourseRegDB.alr.get(i).getindex()){	
				CourseRegDB.alr.get(i).setindex(index1);
			}
			CourseRegDB.save(filename, CourseRegDB.alr);
		}
		
	    for (int i = 0; i < WaitingListDB.alr5.size(); i++){
			if (matric.equals(WaitingListDB.alr5.get(i).getmatric()) && index2==WaitingListDB.alr5.get(i).getindex()){
				WaitingListDB.deleteWaitList(index2,matric);
			}
			if (matric2.equals(WaitingListDB.alr5.get(i).getmatric()) && index1==WaitingListDB.alr5.get(i).getindex()){
				WaitingListDB.deleteWaitList(index1,matric2);
			}
		}
	    
		for (int i = 0; i < StudentDB.alr4.size(); i++) {
			if (matric2.equals(StudentDB.alr4.get(i).getMatric())){
			   name = StudentDB.alr4.get(i).getName();			    
			}
		} 
		System.out.println("You have successfully swapped indexes with " + name + " from " + index1 + " to " + index2);
    }

	/**
	 * Displays all available courses and their indexes as well as the information for each course and index
	 * @throws IOException : thrown if there are issues with reading from the database
	 */
	public static void printCourse() throws IOException
	{
		boolean flag=false;
		boolean check=false;
		String courseCode;
		int index = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("\n==================================================");
		System.out.println(" View Courses ");
		System.out.println("==================================================\n");
		System.out.println("The List of Courses Available Are:\n");
		System.out.println("Code\t\tName\t\tSchool\t\tAUs");
		System.out.println("====================================================");
		for (int i = 0; i < CourseDatabase.alr3.size(); i++){					
			System.out.println(CourseDatabase.alr3.get(i).getcourseCode() + "\t\t" + CourseDatabase.alr3.get(i).getcourseName() + 
					"\t\t" + CourseDatabase.alr3.get(i).getschool() + "\t\t" + CourseDatabase.alr3.get(i).getAu());
		}
		do{
			System.out.println("\nEnter Course Code to view Indexes available: ");	  
			courseCode = sc.next().toUpperCase();
			if (!isCourseValid(courseCode)){
				System.out.println("Invalid Course Code! Please enter again!");
			}
		} while (!isCourseValid(courseCode));
		System.out.println("\nThe indexes available for " + courseCode + " are:\n");
		System.out.println("Index\t\tVacancy");	
		System.out.println("==================================================");
		for (int i = 0; i < IndexDB.alr2.size(); i++){
			if (courseCode.equals(IndexDB.alr2.get(i).getcourseCode())){
				System.out.println(IndexDB.alr2.get(i).getindexNumber() + "\t\t" + IndexDB.alr2.get(i).getvacancy());
			}
		} 
		do{
			int choice =0;
			int sum = 0;
			do {
				boolean cfm=false; 
				boolean cfm2 = false;
				do {
					System.out.println("\nPlease select an option");
					System.out.println("(1): View index information");
					System.out.println("(2): Exit");
					try {
						choice = sc.nextInt();	
					} catch (InputMismatchException e) { 
						System.out.println("Please input integer only");
						sc.next();
						cfm = false;
					}
					cfm = true;
				}while (!cfm);
				if (choice==1){
					do {
					System.out.println("\nEnter Index Number");
					try {
						index = sc.nextInt();
						} catch (InputMismatchException e) { 
								System.out.println("Please input integer only!");
								sc.next();
								cfm2 = true;
						}
					if (checkIndexinCourse(courseCode,index) == false){
						System.out.println("Please enter valid Index Number!");
						cfm2 = true;
					}
					else{
						cfm2 = false;
					}
					} while (cfm2);
					for (int i = 0; i < IndexDB.alr2.size(); i++){
						if (courseCode.equals(IndexDB.alr2.get(i).getcourseCode())){
							if (checkIndexinCourse(courseCode,index) == true){
								System.out.println("\nInformation about " + courseCode +" Index " + index+":");
								sum=getWaitlistCount(index);
								System.out.println("\n" + "Current Waitlist Count: "+ sum);
								if (sum>5){
									System.out.println("Index is severely oversubscribed! Please do not select this index to avoid any disappointments!");
								}
								if (sum>=1 & sum<5){
									System.out.println("Index is oversubscribed! There is a chance you might not get this index!");
								}
								if (sum==0){
									System.out.println("Index is not oversubscribed!");
								} 
								System.out.println("\nTimings:\n");
								System.out.println("Type"+"\t" + "Day" + "\t" + "Venue" + "\t" + "Start" + "\t" + "End");						     
								for (int r = 0; r < TimeSlotDB.alr6.size(); r++){
									if (index ==(TimeSlotDB.alr6.get(r).getindexNumber())){
										System.out.println(TimeSlotDB.alr6.get(r).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(r).getdayOfweek()+"\t" +TimeSlotDB.alr6.get(r).getvenue()+"\t"+TimeSlotDB.alr6.get(r).getstartTime()+"\t"+TimeSlotDB.alr6.get(r).getendTime());
									}
								}
								flag=true;
								break;
							}
							check=true;
							break;
						}
					}
					break;
				}					
				else if (choice==2){
					return;
				}
				else if (choice!=1|choice!=2){
					System.out.println("Please enter a valid option (1 or 2)!");
				}
			}while(!check);
		} while (!flag);
	}

	/**
	 * Checks for the vacancies and wait list count for all indexes of a course
	 * @throws IOException : thrown if there are issues with reading from the database
	 */	
	public static void checkVacancies() throws IOException{
		String input ="";
		Scanner sc = new Scanner(System.in);
		System.out.println("\n==================================================");
		System.out.println(" Check Vacancies ");
		System.out.println("==================================================\n");
		do {
			System.out.print("Please enter the Course Code: ");
			input = sc.next().toUpperCase();	
			if(!isCourseValid(input)){
				System.out.println("Invalid course code. Please enter again.\n");
			}
		} while (!isCourseValid(input));

		if (isCourseValid(input)){
			System.out.println("\nThe vacancies for " + input + " are as listed:\n");
			System.out.println("Index\tVacancy\t\tWaitlist Count");	
			System.out.println("==================================================");

			for (int i = 0; i < IndexDB.alr2.size(); i++){
				if (input.equals(IndexDB.alr2.get(i).getcourseCode())){
					System.out.println(IndexDB.alr2.get(i).getindexNumber() + "\t" + IndexDB.alr2.get(i).getvacancy() +"/" + getClassSize(IndexDB.alr2.get(i).getindexNumber()) +"\t\t"+ getWaitlistCount(IndexDB.alr2.get(i).getindexNumber()));
				}
			} 
		}
	}	

	/**
	 * Checks for the registration status of an index that the student has registered for (eg. Registered/Waitlist)
	 * @param matric The matriculation number of the student
	 * @param index The index number of the student to check the status for
	 * @return returns the status of the course (Registered/Waitlist)
	 */
	public static String courseStatus(String matric, int index)
	{
		String status = "";
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())){
				if (index == (CourseRegDB.alr.get(i).getindex())){
					status = "Registered";
				}
			}
		}
		for (int j = 0; j < WaitingListDB.alr5.size(); j++)	{
			if (matric.equals(WaitingListDB.alr5.get(j).getmatric())){
				if (index == (WaitingListDB.alr5.get(j).getindex())){
					status = "Waitlist";
				}
			}
		}
		return status;
	}

	/**
	 * Displays the information of all courses that the student are registered for/on the wait list for as well as student's timetable
	 * @throws IOException thrown if there are issues with reading the database
	 */	
	public static void registeredCourses() throws IOException
	{
		//CourseRegDB.alr.clear();
		//CourseRegDB.initCourseReg();
		String matric = LoginController.matric();
		Scanner sc = new Scanner(System.in);
		System.out.println("\n==================================================");
		System.out.println(" Check/Print Registered Courses ");
		System.out.println("==================================================\n");
		System.out.println("The courses that you have registered for are\n");
		System.out.println("Course\tIndex\tAUs\tStatus");	
		System.out.println("==================================================");
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())){
				for (int j = 0; j < CourseDatabase.alr3.size(); j++){
					if ((CourseRegDB.alr.get(i).getcourseCode()).equals(CourseDatabase.alr3.get(j).getcourseCode())){			     
						System.out.println(CourseRegDB.alr.get(i).getcourseCode() + "\t" + CourseRegDB.alr.get(i).getindex() + "\t" + CourseDatabase.alr3.get(j).getAu() + "\t" + courseStatus(matric, CourseRegDB.alr.get(i).getindex()));
						break;
					}
				}
			}
		}
		WaitListDetails();
		System.out.println("\nYour current total AUs are: " + getAUs(matric));	
		System.out.println("\nYour Timetable");
		System.out.println("==================================================");
		System.out.println("\nMonday");
		System.out.println("Course" + "\t" +"Index"+ "\t" + "Type"+"\t" + "Venue"+"\t" +"Start" + "\t" + "End");
		for (int r = 0; r < CourseRegDB.alr.size(); r++){
			if (matric.equals(CourseRegDB.alr.get(r).getmatric())){
				for (int s = 0; s < TimeSlotDB.alr6.size(); s++){
					if (CourseRegDB.alr.get(r).getindex()==TimeSlotDB.alr6.get(s).getindexNumber()){
						if (TimeSlotDB.alr6.get(s).getdayOfweek().equals("MON")){
							System.out.println(CourseRegDB.alr.get(r).getcourseCode()+"\t"+TimeSlotDB.alr6.get(s).getindexNumber()+"\t"+TimeSlotDB.alr6.get(s).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(s).getvenue()+"\t" + TimeSlotDB.alr6.get(s).getstartTime()+"\t"+TimeSlotDB.alr6.get(s).getendTime());
							break;
						}
					}
				}
			}
		}
		System.out.println("\nTuesday");
		System.out.println("Course" + "\t" +"Index"+ "\t" + "Type"+"\t" + "Venue"+"\t" +"Start" + "\t" + "End");
		for (int r = 0; r < CourseRegDB.alr.size(); r++){
			if (matric.equals(CourseRegDB.alr.get(r).getmatric())){
				for (int s = 0; s < TimeSlotDB.alr6.size(); s++){
					if (CourseRegDB.alr.get(r).getindex()==TimeSlotDB.alr6.get(s).getindexNumber()){
						if (TimeSlotDB.alr6.get(s).getdayOfweek().equals("TUE")){
							System.out.println(CourseRegDB.alr.get(r).getcourseCode()+"\t"+TimeSlotDB.alr6.get(s).getindexNumber()+"\t"+TimeSlotDB.alr6.get(s).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(s).getvenue()+"\t" + TimeSlotDB.alr6.get(s).getstartTime()+"\t"+TimeSlotDB.alr6.get(s).getendTime());
							break;
						}
					}
				}
			}
		}
		System.out.println("\nWednesday");
		System.out.println("Course" + "\t" +"Index"+ "\t" + "Type"+"\t" + "Venue"+"\t" +"Start" + "\t" + "End");
		for (int r = 0; r < CourseRegDB.alr.size(); r++){
			if (matric.equals(CourseRegDB.alr.get(r).getmatric())){
				for (int s = 0; s < TimeSlotDB.alr6.size(); s++){
					if (CourseRegDB.alr.get(r).getindex()==TimeSlotDB.alr6.get(s).getindexNumber()){
						if (TimeSlotDB.alr6.get(s).getdayOfweek().equals("WED")){
							System.out.println(CourseRegDB.alr.get(r).getcourseCode()+"\t"+TimeSlotDB.alr6.get(s).getindexNumber()+"\t"+TimeSlotDB.alr6.get(s).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(s).getvenue()+"\t" + TimeSlotDB.alr6.get(s).getstartTime()+"\t"+TimeSlotDB.alr6.get(s).getendTime());
							break;
						}
					}
				}
			}
		}
		System.out.println("\nThursday");
		System.out.println("Course" + "\t" +"Index"+ "\t" + "Type"+"\t" + "Venue"+"\t" +"Start" + "\t" + "End");
		for (int r = 0; r < CourseRegDB.alr.size(); r++){
			if (matric.equals(CourseRegDB.alr.get(r).getmatric())){
				for (int s = 0; s < TimeSlotDB.alr6.size(); s++){
					if (CourseRegDB.alr.get(r).getindex()==TimeSlotDB.alr6.get(s).getindexNumber()){
						if (TimeSlotDB.alr6.get(s).getdayOfweek().equals("THU")){
							System.out.println(CourseRegDB.alr.get(r).getcourseCode()+"\t"+TimeSlotDB.alr6.get(s).getindexNumber()+"\t"+TimeSlotDB.alr6.get(s).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(s).getvenue()+"\t" + TimeSlotDB.alr6.get(s).getstartTime()+"\t"+TimeSlotDB.alr6.get(s).getendTime());
							break;
						}
					}
				}
			}
		}
		System.out.println("\nFriday");
		System.out.println("Course" + "\t" +"Index"+ "\t" + "Type"+"\t" + "Venue"+"\t" +"Start" + "\t" + "End");
		for (int r = 0; r < CourseRegDB.alr.size(); r++){
			if (matric.equals(CourseRegDB.alr.get(r).getmatric())){
				for (int s = 0; s < TimeSlotDB.alr6.size(); s++){
					if (CourseRegDB.alr.get(r).getindex()==TimeSlotDB.alr6.get(s).getindexNumber()){
						if (TimeSlotDB.alr6.get(s).getdayOfweek().equals("FRI")){
							System.out.println(CourseRegDB.alr.get(r).getcourseCode()+"\t"+TimeSlotDB.alr6.get(s).getindexNumber()+"\t"+TimeSlotDB.alr6.get(s).gettypeOfLesson()+"\t"+TimeSlotDB.alr6.get(s).getvenue()+"\t" + TimeSlotDB.alr6.get(s).getstartTime()+"\t"+TimeSlotDB.alr6.get(s).getendTime());
							break;
						}
					}
				}
			}
		}
	}

	/**
	 * Gets the details of a course that the logged in student is currently on the wait list for 
	 */
	public static void WaitListDetails()
	{
		String matric = LoginController.matric();
		for (int i = 0; i < WaitingListDB.alr5.size(); i++){
			if (matric.equals(WaitingListDB.alr5.get(i).getmatric())){
				for (int j = 0; j < IndexDB.alr2.size(); j++){
					if (WaitingListDB.alr5.get(i).getindex()==IndexDB.alr2.get(j).getindexNumber()){
						for (int k = 0; k < CourseDatabase.alr3.size(); k++){
							if (IndexDB.alr2.get(j).getcourseCode().equals(CourseDatabase.alr3.get(k).getcourseCode())){
								System.out.println(CourseDatabase.alr3.get(k).getcourseCode() + "\t" + IndexDB.alr2.get(j).getindexNumber() + "\t" + CourseDatabase.alr3.get(k).getAu() + "\t" + courseStatus(matric, IndexDB.alr2.get(j).getindexNumber()));
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Dropping a course for the student that is currently logged in
	 * @throws IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */	
	public static void dropCourse() throws IOException, AddressException 
	{
		String courseCode = "";
		System.out.println("\n==================================================");
		System.out.println(" Drop Course ");
		System.out.println("==================================================\n");		
		Scanner sc = new Scanner(System.in);
		String matric = LoginController.matric();
		System.out.println("The courses that you have registered/pending for are\n");
		System.out.println("Course\tIndex\tStatus");	
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())){
				System.out.println(CourseRegDB.alr.get(i).getcourseCode() + "\t" + CourseRegDB.alr.get(i).getindex() + "\t" + courseStatus(matric, CourseRegDB.alr.get(i).getindex()));
			}

		}
		for (int j = 0; j < WaitingListDB.alr5.size(); j++){
			if (matric.equals(WaitingListDB.alr5.get(j).getmatric())){
				for (int k = 0; k < IndexDB.alr2.size(); k++)
				{
					if (WaitingListDB.alr5.get(j).getindex()  == IndexDB.alr2.get(k).getindexNumber())
					{
						courseCode = IndexDB.alr2.get(k).getcourseCode();
					}
				}
				System.out.println(courseCode + "\t" + WaitingListDB.alr5.get(j).getindex() + "\t" + courseStatus(matric, WaitingListDB.alr5.get(j).getindex()));
			}
		}
		boolean flag = false;
		int index = 0;
		int choice =0;
		boolean waitlist = false;
		do { 
			boolean cfm=false; 
			do {
				System.out.println("\nEnter the index number that you want to drop: ");
				try {
					index = sc.nextInt();	
					cfm = true;
				} catch (InputMismatchException e) { 
					System.out.println("Please input integer only!");
					sc.next();
					cfm = false;
				}

			}while (!cfm);

			for (int i = 0; i < CourseRegDB.alr.size(); i++){
				if (CourseRegDB.alr.get(i).getmatric().equals(matric) & CourseRegDB.alr.get(i).getindex() == index){
					flag = true;
					break;
				}
			}
			for (int j = 0; j < WaitingListDB.alr5.size(); j++){
				if (WaitingListDB.alr5.get(j).getmatric().equals(matric) & WaitingListDB.alr5.get(j).getindex() == index){
					waitlist = true;
					flag = true;
					break;
				}
			}
			if (!flag){
				System.out.print("You are not registered for this index\n");
			}
		} while (!flag);

		do {
			System.out.println("\nConfirm to drop the course?");
			System.out.println("(1): Confirm");
			System.out.println("(2): Exit");
			choice = sc.nextInt();
			if (choice==1){
				break;
			}
			else if (choice==2){
				return;
			}
			else if (choice!=1|choice!=2){
				System.out.println("Please enter a valid option (1 or 2)!");
			}
		} while (choice!=1|choice!=2);

		if (waitlist){
			WaitingListDB.deleteWaitList(index,matric);
			System.out.println("You have successfully dropped the course from the Waiting List!");
			return;
		}

		if (isIndexInWaitList(index)){
			if (isVacancyZero(index)){
				checkWaitList(index,"\\|");
			}
		}
		else{
			for (int i = 0; i < IndexDB.alr2.size(); i++) 
				if (IndexDB.alr2.get(i).getindexNumber() == index){
					IndexDB.alr2.get(i).setvacancy(IndexDB.alr2.get(i).getvacancy()+1);
				}
		}
		CourseRegDB.deleteCourseReg(index,matric);	
		CourseRegDB.alr.clear();
		CourseRegDB.initCourseReg();
		IndexDB indexDB2 = new IndexDB();
		indexDB2.updateIndexes(filename1, IndexDB.alr2);
		System.out.println("You have successfully dropped the course!");
	}


	/**
	 * Getting the corresponding course code for a particular index number
	 * @param index The index number to get the corresponding course code for
	 * @return returns the course code that the index belongs to
	 */	
	public static String getCourseCodefromIndex(int index){
		String courseCode = "";
		for (int j = 0; j < IndexDB.alr2.size(); j++){
			if (index == IndexDB.alr2.get(j).getindexNumber()){
				courseCode = IndexDB.alr2.get(j).getcourseCode();
			}
		}
		return courseCode;
	}

	/**
	 * Getting the first matriculation number in the wait list for a particular index number
	 * @param index The index number to get the first matriculation number for
	 * @return returns the matriculation number of the first person in the waitlist for the index
	 */	
	public static String getFirstWaitList(int index) 
	{
		String matric = "";
		for (int i = 0; i < WaitingListDB.alr5.size(); i++){
			if (index == WaitingListDB.alr5.get(i).getindex()){
				matric = WaitingListDB.alr5.get(i).getmatric();
				break;
			}
		}
		return matric;
	}

	/**
	 * Checks the wait list to register a student on the wait list for an index that now has vacancy
	 * @param index The index number to check the wait list for
	 * @param delimiter Delimiter to manipulate the waiting list text file
	 * @throws IOException : IOException : thrown if there are issues with updating the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */
	public static void checkWaitList(int index,String delimiter) throws IOException, AddressException
	{
		String matric = "";
		String courseCode = "";
		Scanner sc = new Scanner(System.in);
		CourseReg c = new CourseReg();
		c.setindex(index);
		matric = getFirstWaitList(index);
		c.setmatric(matric);
		courseCode = getCourseCodefromIndex(index);
		c.setcourseCode(courseCode);
		if (checkRecordInCR(matric,courseCode)==true){
			for (int i = 0; i < CourseRegDB.alr.size(); i++){
				if (matric.equals(CourseRegDB.alr.get(i).getmatric())){
					if (courseCode.equals(CourseRegDB.alr.get(i).getcourseCode())){
						for (int j = 0; j < IndexDB.alr2.size(); j++){
							if (CourseRegDB.alr.get(i).getindex() == IndexDB.alr2.get(j).getindexNumber()){
								IndexDB.alr2.get(j).setvacancy(IndexDB.alr2.get(j).getvacancy()+1);
								IndexDB indexDB2 = new IndexDB();
								indexDB2.updateIndexes(filename1, IndexDB.alr2);
							}
						}
						CourseRegDB.alr.get(i).setindex(index);
						CourseRegDB.save(filename, CourseRegDB.alr);
						WaitingListDB.deleteWaitList(index,matric);
					}
				}					   
			}		   
		}
		else{
			CourseRegDB.alr.add(c);
			CourseRegDB.save(filename, CourseRegDB.alr);
			WaitingListDB.deleteWaitList(index,matric);
		}
		WaitingListDB.alr5.clear();
		WaitingListDB.initWaitingList();
		Student checkStud = new Student();
		Student s = new Student();
		s.setMatric(matric);
		checkStud = StudentController.retrieveStudent(s);
		String email = checkStud.getEmail();
		String name = checkStud.getName();
		MailController.SendRegisteredMail(email, index, courseCode, name);
	}
	/**
	 * Calculating the total number of Academic Units(AUs) that the logged in student currently has
	 * @param matric The matriculation number of the student to calculate the total AUs for
	 * @return return the total AUs that the student is currently enrolled for
	 */	
	public static int getAUs(String matric) 
	{
		int sum = 0;
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())){
				for (int j = 0; j < CourseDatabase.alr3.size(); j++){
					if ((CourseRegDB.alr.get(i).getcourseCode()).equals(CourseDatabase.alr3.get(j).getcourseCode())){			     
						sum += CourseDatabase.alr3.get(j).getAu();
					}
				}
			}
		}
		return sum;
	}

	/**
	 * Calculating how many people are in the wait list for a particular index number
	 * @param index The index number to calculate the wait list count for
	 * @return returns the current number of students on the waitlist for the index
	 * @throws IOException : IOException : thrown if there are issues with reading from the database
	 */	  
	public static int getWaitlistCount(int index) throws IOException
	{
		WaitingListDB.alr5.clear();
		WaitingListDB.initWaitingList();
		int sum = 0;
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < WaitingListDB.alr5.size(); i++){
			if (index == (WaitingListDB.alr5.get(i).getindex())){
				sum+=1;
			}
			else if (index != (WaitingListDB.alr5.get(i).getindex())){
				sum=0;
			}
		}
		return sum;  
	}

	/**
	 * Calculating the class size for a particular index number
	 * @param index The index number to calculate the class size for
	 * @return returns the total class size of the index
	 */	 
	public static int getClassSize(int index) 
	{
		int size1=0;
		int size2=0;
		for (int i = 0; i < CourseRegDB.alr.size(); i++){
			if(CourseRegDB.alr.get(i).getindex() == index){
				size1+=1;
			}
		}
		for (int j = 0; j < IndexDB.alr2.size(); j++){
			if(IndexDB.alr2.get(j).getindexNumber() == index){
				size2 = IndexDB.alr2.get(j).getvacancy();
			}
		}
		return size1+size2;
	}

	/**
	 * Getting the current vacancy for a particular index number
	 * @param index The index number to get the vacancy for
	 * @return returns the current vacancy of the index
	 */	
	public static int getVacancy(int index) 
	{
		int vac=0;
		for (int i = 0; i < IndexDB.alr2.size(); i++){
			if(isIndexExists(index)){
				vac = IndexDB.alr2.get(i).getvacancy();
			}
		}
		return vac;
	}
}			