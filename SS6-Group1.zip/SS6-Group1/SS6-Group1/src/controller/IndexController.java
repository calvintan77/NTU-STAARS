package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import database.CourseDatabase;
import entity.Course;
import entity.Index;
import entity.TimeSlot;
import database.IndexDB;
import database.TimeSlotDB;

/**
 * Manager to handle all Index related tasks
 * @author GUO FEIYAN
 *
 */
public class IndexController {
	
	/**
	 * Create a new Index for a specific course
	 * @param courseCode The Course code of the course that the index belongs to
	 * @return The new Index Object that has been created for the course
	 */
	public static Index createIndex(String courseCode) {
		Scanner sc = new Scanner(System.in);
		int index = dupIndex(" ");
		int vacancy = CourseController.valueCheck("vacancies");
		int numOfTimeslot = CourseController.valueCheck("timeslots");
		for(int m=0; m<numOfTimeslot; m++) {
			int type1_3 = TimeSlotController.typeCheck(m);
			String typeOfLesson = TimeSlotController.getType(type1_3);
			int day1_7 = TimeSlotController.dayCheck();
			String dayOfWeek = TimeSlotController.getDay(day1_7);
			String startTime = TimeSlotController.startCheck(index, dayOfWeek);
			String endTime = TimeSlotController.endCheck(index, dayOfWeek, startTime);
			String venue = TimeSlotController.checkVenue(dayOfWeek,startTime,endTime);
			TimeSlot t = new TimeSlot(index,typeOfLesson,dayOfWeek,venue,startTime,endTime);
			TimeSlotController.addTimeslot(t);
		}
		Index i = new Index(courseCode, index, vacancy, numOfTimeslot);
		addIndex(i);
		return i;
	}
	
	/**
	 * Add a new Index
	 * @param i Index Object to be added
	 */
	public static void addIndex(Index i) {
		try {
			ArrayList newIndex = new ArrayList();
			newIndex.add(i);
			IndexDB.saveIndexes("index.txt",newIndex);
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	
	/**
	 * To remove a specific index from a course
	 * @param removeIndex The index number to be removed
	 */
	public static void removeIndex(int removeIndex) {
		String removeindex = String.valueOf(removeIndex);
		CourseDatabase.removeRecord("index.txt",removeindex,3,"\\|");
		CourseDatabase.removeRecord("timeslot.txt",removeindex,1,"\\|");
	}
	
	/**
	 * Update the number of vacancies in the Index Object
	 * @param indexNumber The index number of the Index Object
	 * @param newVacancy The new number of vacancies for this Index Object to be updates
	 */
	public static void updateVacancy(int indexNumber, int newVacancy) {
		try {
			ArrayList current = IndexDB.readIndexes("index.txt");
			PrintWriter id = new PrintWriter("index.txt");
			id.close();
			for (int i = 0 ; i < current.size() ; i++) {
				Index in = (Index)current.get(i);
				if(in.getindexNumber() == indexNumber) {
					in.setvacancy(newVacancy);
				}
			}
			IndexDB.saveIndexes("index.txt",current);
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	
	/**
	 * Update the Index number
	 * @param indexNumber The current Index number of the Index Object
	 * @param newIndex The new Index number that is to be updated
	 */
	public static void updateIndex(int indexNumber, int newIndex) {
		try {
			ArrayList current = IndexDB.readIndexes("index.txt");
			PrintWriter id = new PrintWriter("index.txt");
			id.close();
			ArrayList current2 = TimeSlotDB.readTimeslots("timeslot.txt");
			PrintWriter id2 = new PrintWriter("timeslot.txt");
			id2.close();
			for (int i = 0 ; i < current.size() ; i++) {
				Index in = (Index)current.get(i);
				
				if(in.getindexNumber() == indexNumber) {
					in.setindexNumber(newIndex); 
				}		
			}
			for (int i = 0 ; i < current2.size() ; i++) {
				TimeSlot ts = (TimeSlot)current2.get(i);
				if(ts.getindexNumber() == indexNumber) {
					ts.setindexNumber(newIndex); 
				}		
			}
			IndexDB.saveIndexes("index.txt",current);
			TimeSlotDB.saveTimeslots("timeslot.txt", current2);
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	
	/**
	 * To print all the indexes available
	 */
	public static void printIndex() {
		try {
			ArrayList current = IndexDB.readIndexes("index.txt");
			for (int i = 0 ; i< current.size() ; i++) {
				Index in = (Index)current.get(i);
				System.out.println("Course code : " + in.getcourseCode());
				System.out.println("Index number : " + in.getindexNumber());
			}
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	
	/**
	 * Check the validity of the Index Number
	 * @param oldnew The index number to be checked
	 * @return the index number after being checked
	 */
	public static int dupIndex(String oldnew) {
		Scanner sc = new Scanner(System.in);
		int value = 0;
		while (true) {
			boolean check = true;
			System.out.print("\nEnter"+ oldnew + "Index number: ");
            String input = sc.next();
            try {
                value = Integer.parseInt(input);
                if(value < 0) {
                	System.out.println("Error: Invalid Index number.");
                	continue;
                }
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
                continue;
            }
            try {
        		ArrayList current = IndexDB.readIndexes("index.txt");
    			for (int i=0 ; i<current.size() ; i++) {
    				Index in = (Index)current.get(i);
    				if(in.getindexNumber()==value) {
    					System.out.println("Error: Index Number already exist.");
    					check = false;
    					break;
    				}
    			}
    			if(check) {
					return value;
				}
    			continue;
        		}catch (IOException e) {
        			System.out.println("IOException > " + e.getMessage());
        		}
        }
		
	}
	public static int existIndex() {
		Scanner sc = new Scanner(System.in);
		int value = 0;
		while (true) {
			System.out.print("\nEnter Index number: ");
            String input = sc.next().toUpperCase();
            try {
                value = Integer.parseInt(input);
                if(value < 0) {
                	System.out.println("Error: Invalid Index number.");
                	continue;
                }
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
                continue;
            }
            try {
        		ArrayList current = IndexDB.readIndexes("index.txt");
    			for (int i=0 ; i<current.size() ; i++) {
    				Index in = (Index)current.get(i);
    				if(in.getindexNumber()==value) {
    					return value;
    				}
				}
    			System.out.println("Error: Index number does not exist.");
    			continue;
        		}catch (IOException e) {
        			System.out.println("IOException > " + e.getMessage());
        		}
        }
	}
	

}

