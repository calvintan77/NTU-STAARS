package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.PrintWriter;

import entity.Index;
import database.CourseDatabase;
import entity.Course;
import database.IndexDB;
import database.ReadinFile;
import database.StudentDB;

/**
 * A manager to handle all course related tasks
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-21
 */
public class CourseController {
	/**
	 * separator to manipulate text files
	 */
	public static final String SEPARATOR = "|";
	
	/**
	 * Add new courses
	 * @return the array of courses added
	 */
	public static ArrayList createCourse() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("\n==================================================");
		System.out.println("Add a new course ");
		System.out.println("==================================================\n");
		
		System.out.print("Enter Course Name: ");
		String courseName = sc.next().toUpperCase();
		courseName = dupName(courseName);
		
		System.out.print("\nEnter Course Code: ");
		String courseCode = sc.next().toUpperCase();
		courseCode = dupCode(courseCode);
		
		int au = valueCheck("AUs");
		
		String school = checkAlpha();
		
		int numberOfIndex = valueCheck("Indexes");
		
		for(int n=0 ; n<numberOfIndex ; n++) {
			Index i = IndexController.createIndex(courseCode);
		}
		
		Course c = new Course(numberOfIndex,courseName,courseCode,au,school);
		ArrayList al = new ArrayList();
		al.add(c);
		return al;
	}

	/**
	 * To add new courses
	 * @throws IOException thrown if there are issues with printing of the course list
	 */
	public static void addCourse() throws IOException {
		try {
			
			ArrayList newCourse = new ArrayList();
			newCourse.addAll(createCourse());
			ArrayList CourseList = new ArrayList();
			ArrayList IndexList = new ArrayList();
			CourseList.add(newCourse.get(0));
			newCourse.remove(0); 
			IndexList.addAll(newCourse);
			Course c = (Course)CourseList.get(0);
			CourseDatabase.saveCourses("course.txt",CourseList);
			IndexDB.saveIndexes("index.txt",IndexList);
			System.out.println("\nCourse has been succesfully added!");
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		
		// to list all courses after addition of a new course
		printCourse();
	}
	
	/**
	 * Print all of the courses that are currently available from the database
	 * @throws IOException thrown if there are issues with reading the Course text file
	 */
	public static void printCourse() throws IOException{
		System.out.println("\n==================================================");
		System.out.println("List of current courses");
		System.out.print("==================================================\n\n");
		System.out.println("Index	 Course Code    Course Name");
		System.out.print("==================================================\n");

		ArrayList stringArray = (ArrayList)ReadinFile.read("course.txt"); //read string from text file
		for (int j = 0; j < stringArray.size(); j++)
		{
			String st = (String)stringArray.get(j);
			StringTokenizer star = new StringTokenizer(st, SEPARATOR);
		    String numberofIndex = star.nextToken().trim();
		    int numofIndex = Integer.parseInt(numberofIndex.trim());
		    String courseName = star.nextToken().trim(); 
			String courseCode = star.nextToken().trim(); 
			String Au = star.nextToken().trim();
			int au = Integer.parseInt(Au.trim());
			String school = star.nextToken().trim();
			System.out.printf("%-10s", j+1);
			System.out.printf("%-15s", courseCode);
			System.out.printf("%-15s\n", courseName);
		}
	}
	
	/**
	 * To delete courses that are currently available
	 * @param courseCode The course code of the course to delete
	 */
	public static void deleteCourse(String courseCode) {
		boolean exist = false;
		try {
			ArrayList current = IndexDB.readIndexes("index.txt");
			for(int i=0; i<current.size();i++) {
				Index in = (Index)current.get(i);
				if (in.getcourseCode().equals(courseCode)) {
					int indexNumber = in.getindexNumber();
					String index = String.valueOf(indexNumber);
					CourseDatabase.removeRecord("timeslot.txt", index , 1 , "\\|");
					exist = true;
				}
			}
			if(!exist) {
				System.out.println(courseCode + " does not exist.");
			}
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		CourseDatabase.removeRecord("course.txt",courseCode,3,"\\|");
		CourseDatabase.removeRecord("index.txt",courseCode,1,"\\|");
		System.out.println("The course" + courseCode + " has been deleted!");
	}
	
	/**
	 * To update/change the current course code with a new one
	 * @param courseCode The course code that administrator wants to update
	 * @param newcourseCode This course's new course code
	 */
	public static void updatecourseCode(String courseCode, String newcourseCode) {
		try {
			CourseDatabase.alr3.clear();
			IndexDB.alr2.clear();
			ArrayList current = CourseDatabase.readCourses("course.txt");
			ArrayList current2 = IndexDB.readIndexes("index.txt");
			PrintWriter id = new PrintWriter("course.txt");
			PrintWriter id2 = new PrintWriter("index.txt");
			id.close();
			id2.close();
			for (int i = 0 ; i < current.size() ; i++) {
				Course course = (Course)current.get(i);
				if(course.getcourseCode().equals(courseCode)) {
					course.setcourseCode(newcourseCode);
				}
			}
			for (int i = 0 ; i < current2.size() ; i++) {
				Index in = (Index)current2.get(i);
				if(in.getcourseCode().equals(courseCode)) {
					in.setcourseCode(newcourseCode);
				}
			}
			CourseDatabase.saveCourses("course.txt",current);
			IndexDB.saveIndexes("index.txt",current2);
			current.clear();
			current2.clear();
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		System.out.println("Course code for " + courseCode + " has been successfully updated!");		
	}
	
	/**
	 * To update the faculty the course belongs to
	 * @param courseCode The course code that admin wants to update
	 * @param newSchool This course's new faculty
	 */
	public static void updateSchool(String courseCode, String newSchool) {
		try {
			CourseDatabase.alr3.clear();
			ArrayList current = CourseDatabase.readCourses("course.txt");
			PrintWriter id = new PrintWriter("course.txt");
			id.close();
			for (int i = 0 ; i < current.size() ; i++) {
				Course course = (Course)current.get(i);
				if(course.getcourseCode().equals(courseCode)) {
					course.setschool(newSchool);
				}
			}
			CourseDatabase.saveCourses("course.txt",current);
			current.clear();
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		System.out.println("School for " + courseCode + " has been successfully updated!");
	}
	
	/**
	 * Update the number of academic units the course fulfills
	 * @param courseCode The course code that administrator wants to update
	 * @param newAu This course's new number of academic units
	 */
	public static void updateAu(String courseCode, int newAu) {
		try {
			CourseDatabase.alr3.clear();
			ArrayList current = CourseDatabase.readCourses("course.txt");
			PrintWriter id = new PrintWriter("course.txt");
			id.close();
			for (int i = 0 ; i < CourseDatabase.alr3.size() ; i++) {
				Course course = (Course)current.get(i);
				if(course.getcourseCode().equals(courseCode)) {
					course.setAu(newAu);
				}
			}
			CourseDatabase.saveCourses("course.txt",current);
			current.clear();
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		System.out.println("Aus for " + courseCode + " has been successfully updated!");
	}
	
	/**
	 * To update the course's name 
	 * @param courseName The course name that the administrator wants to update
	 * @param newcourseName This course's new name
	 */
	public static void updatecourseName(String courseName, String newcourseName) {
		try {
			CourseDatabase.alr3.clear();
			ArrayList current = CourseDatabase.readCourses("course.txt");
			PrintWriter id = new PrintWriter("course.txt");
			id.close();
			for (int i = 0 ; i < current.size() ; i++) {
				Course course = (Course)current.get(i);
				if(course.getcourseName().equals(courseName)) {
					course.setCourseName(newcourseName);
				}
			}
			CourseDatabase.saveCourses("course.txt",current);
			current.clear();
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
		}
		System.out.println("Course name has been successfully updated!");
	}
	
	/**
	 * To record the number of academic units of the course or the number of indexes the course has
	 * @param variable AU or index
	 * @return this course's number of AUs or the number of indexes
	 */
	public static int valueCheck(String variable) {
		Scanner sc = new Scanner(System.in);
		int value = 0;
		while (true) {
			System.out.println("");
			System.out.print("Enter number of "+ variable +": ");
            String input = sc.next();
            try {
                value = Integer.parseInt(input);
                if(value <= 0) {
                	System.out.println("Error: Invalid number of " + variable +".");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
            }
        }
		return value;
	}
	
	/**
	 * Update the course details
	 */
	public static void UpdateCourse() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\n==================================================");
		System.out.println(" Update Course");
		System.out.println("==================================================\n");
		System.out.println("Enter your choice: ");
		System.out.println("(1): Edit course");
		System.out.println("(2): Delete course");
		int choice = choiceCheck(1,2);
		switch(choice) {
		case 1:
			System.out.println("\n==================================================");
			System.out.println(" Edit course");
			System.out.println("==================================================\n");
			System.out.println("Enter your choice: ");
			System.out.println("(1): Update course name");
			System.out.println("(2): Update course code");
			System.out.println("(3): Update amount of AU");
			System.out.println("(4): Update school name");
			System.out.println("(5): Edit index");
			int choice2 = choiceCheck(1,5);
			switch(choice2) {
			case 1:
				System.out.println("\n==================================================");
				System.out.println(" Update Course Name");
				System.out.println("==================================================\n");
				System.out.print("Course name to be updated: ");
				String courseName = sc.next().toUpperCase();
				System.out.print("\nNew course name: ");
				String New = sc.next().toUpperCase();
				String newcourseName = dupName(New);
				CourseController.updatecourseName(courseName, newcourseName);
				break;
			case 2:
				System.out.println("\n==================================================");
				System.out.println(" Update Course Code");
				System.out.println("==================================================\n");
				String courseCode = existCode();
				System.out.print("\nNew course code: ");
				New = sc.next().toUpperCase();
				String newcourseCode = dupCode(New);
				CourseController.updatecourseCode(courseCode, newcourseCode);
				break;
			case 3:
				System.out.println("\n==================================================");
				System.out.println(" Update Number of AUs");
				System.out.println("==================================================\n");
				courseCode = existCode();
				int newAu = valueCheck("AUs");
				CourseController.updateAu(courseCode, newAu);
				break;
			case 4:
				System.out.println("\n==================================================");
				System.out.println(" Update School");
				System.out.println("==================================================\n");
				courseCode = existCode();
				String newSchool = checkAlpha();
				CourseController.updateSchool(courseCode, newSchool);
				break;
			case 5:
				System.out.println("\n==================================================");
				System.out.println(" Edit Index");
				System.out.println("==================================================\n");
				System.out.println("Enter your choice: ");
				System.out.println("1. Add Index");
				System.out.println("2. Remove Index");
				System.out.println("3. Update Index number");
				System.out.println("4. Update Vacancy");
				int choice3 = choiceCheck(1,4);
				switch(choice3) {
				case 1:
					System.out.println("");
					courseCode = existCode();
					IndexController.createIndex(courseCode);
					break;
				case 2:
					System.out.println("\nIndex number to be removed: ");
					int removeIndex = sc.nextInt();
					IndexController.removeIndex(removeIndex);
					break;
				case 3:
					int indexNumber = IndexController.existIndex();
					int newIndex = IndexController.dupIndex(" new ");
					IndexController.updateIndex(indexNumber, newIndex);
					break;
				case 4:
					indexNumber = IndexController.existIndex();
					int newVacancy = CourseController.valueCheck("vacancies");
					IndexController.updateVacancy(indexNumber, newVacancy);
					break;
				}
			}
			break;
			case 2:
				System.out.println("\n==================================================");
				System.out.println(" Delete Course");
				System.out.println("==================================================\n");
				System.out.println("Course code to be deleted: ");
				String courseCode = sc.next().toUpperCase();
				CourseController.deleteCourse(courseCode);
				break;
		}
	}
	
	/**
	 * Used to check user int choice inputs
	 * @param first First possible choice
	 * @param last Last possible choice
	 * @return returns the choice that the user made
	 */
	public static int choiceCheck(int first, int last) {
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		while (true) {
			System.out.print("\nEnter Choice "+ first + "-" + last +": ");
            String input = sc.next();
            try {
                choice = Integer.parseInt(input);
                if(choice<first || choice>last) {
                	System.out.println("Error: Invalid choice.");
                	continue;
                }
                break;
            } catch (NumberFormatException ne) {
                System.out.println("Error: This is not a number.");
            }
        }
		return choice;
	}
	
	/**
	 * Record faculty that course belongs to
	 * @return this course's faculty name
	 */
	public static String checkAlpha() {
		Scanner sc = new Scanner(System.in);
		String alpha = "[a-zA-Z.*\\s+.]+";
		String school = "";
		do {
			System.out.println("");
			System.out.print("Enter School name: ");
			school = sc.nextLine().toUpperCase();
			
			// check for blank or non-alphabetic inputs
			if (school.equals("") || !school.matches(alpha)) {
				System.out.println("Please enter valid school");
			}
		} while (school.equals("") || !school.matches(alpha));
		return school;
	}
	
	/**
	 * Checking for duplicate course name in the database
	 * @param courseName The course name that is to be checked
	 * @return returns course name
	 */
	public static String dupName(String courseName) {
		boolean check = true;
		Scanner sc = new Scanner(System.in);
		try {
		ArrayList current = CourseDatabase.readCourses("course.txt");
		while(check) {
			for (int i=0 ; i<current.size() ; i++) {
				Course co = (Course)current.get(i);
				if(co.getcourseName().equals(courseName)) {
					System.out.println("Error: Course Name already exist.\n");
					System.out.println("Enter Course Name: ");
					courseName = sc.next().toUpperCase();
					break;
				}
				else
					check = false;
			}
		}
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
	
		}
		return courseName;
	}
	
	/**
	 * Checking for duplicate course code in the database
	 * @param courseCode The course code that is to be checked
	 * @return returns course code
	 */
	public static String dupCode(String courseCode) {
		boolean check = true;
		Scanner sc = new Scanner(System.in);
		try {
		ArrayList current = CourseDatabase.readCourses("course.txt");
		while(check) {
			for (int i=0 ; i<current.size() ; i++) {
				Course co = (Course)current.get(i);
				if(co.getcourseCode().equals(courseCode)) {
					System.out.println("Error: Course Code already exist.\n");
					System.out.println("Enter Course Code: ");
					courseCode = sc.next().toUpperCase();
					break;
				}
				else
					check = false;
			}
		}
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
	
		}
		return courseCode;
	}
	public static String existCode() {
		Scanner sc = new Scanner(System.in);
		String input = "";
		try {	
		ArrayList current = CourseDatabase.readCourses("course.txt");
		while(true) {
			System.out.print("Enter coursecode: ");
            input = sc.next().toUpperCase();
			for (int i=0 ; i<current.size() ; i++) {
				Course co = (Course)current.get(i);
				if(co.getcourseCode().equals(input)) {
					return input;
				}
			}
			System.out.println("Error: Course code does not exist.\n");
		}
		}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
	
		}
		return input;
	}
}