package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import entity.Student;

/**
 * Manager that handles all the tasks related to access time that requires the Calendar
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-22
 */
public class CalendarController {
	
	/**
	 * Convert Calendar to String of the right format to store into the database
	 * @param cal The Calendar object to be converted to String
	 * @return the String format of the Calendar object passed in
	 */
	public static String dateToString(Calendar cal) {
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		int minute = cal.get(Calendar.MINUTE);
		return String.format("%02d/%02d/%4d %02d:%02d", day, month+1, year, hour, minute);
	}
	
	/**
	 * To check if date time passed in is correct for start and end access time
	 * @param mode Either "Access Start Time" or "Access End Time"
	 * @return the Access Start Time or the Access End Time in the form of a Calendar object
	 */
	public static Calendar getValidDateTime(String mode) {
		String date = "";
		Date parsedDate = null;
		boolean validDate = false;
		boolean valid = false;
		Scanner sc = new Scanner(System.in);
		Calendar newDate = Calendar.getInstance();
		do {
			System.out.print("\nEnter " + mode + "(dd/MM/yyyy HH:mm): ");
			date = sc.nextLine();		
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			try {
				dateFormat.parse(date);
				dateFormat.setLenient(false);
				valid = true;
				parsedDate = dateFormat.parse(date);
			} catch (ParseException e) {
				System.out.println("Input is either not in the correct format or you have keyed in an invalid date/time!");
				valid = false;
				continue;
			}
			newDate.setTime(parsedDate);
			validDate = true;
		} while (!validDate);
		
		return newDate;		
	}
	
	/**
	 * To edit the student's access time
	 */
	public static void editAccessTime() {
		String updateSelection = "";
		do{
			Scanner sc = new Scanner(System.in);
			Boolean flag = false;
			String matric = "";
			
			System.out.println("\n==================================================");
			System.out.println(" Edit Student's Access Time Period ");
			System.out.println("==================================================\n");
			
			do {
				System.out.print("Enter the student's matric number: ");
				matric = sc.nextLine();
				Student s = new Student();
				s.setMatric(matric.toUpperCase());
				Student check = new Student();
				check = StudentController.retrieveStudent(s);
				if (check != null)
					flag = true;
				if (!flag) {
					System.out.println("Matric number is not found in database.\n");
				} 
				
			} while (!flag);
			
			Calendar newAccessStart = getValidDateTime("Access Start Time");
			Calendar newAccessEnd = getValidDateTime("Access End Time");
			while (newAccessEnd.before(newAccessStart) || (newAccessEnd.compareTo(newAccessStart) == 0)) {
				System.out.println("The Access End Time cannot be before or at the same time to the Access Start Time!");
				newAccessEnd = getValidDateTime("Access End Time");
			}
			String finalAccessStart = dateToString(newAccessStart);
			String finalAccessEnd = dateToString(newAccessEnd);
			StudentController.updateAccessPeriod(matric, finalAccessStart, finalAccessEnd);
			
			do {	
				System.out.println("Do you want to continue? ");
				System.out.println("(1): Yes");
				System.out.println("(2): No");
				updateSelection = sc.nextLine();

		
				if ((!updateSelection.equals("1")) && (!updateSelection.equals("2")))
				{	
					System.out.println("Please enter a valid option");
				}
			} while ((!updateSelection.equals("1")) && (!updateSelection.equals("2")));
		} while (updateSelection.equals("1"));		
	}
}
