package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import database.CourseDatabase;
import database.CourseRegDB;
import database.IndexDB;
import database.StudentDB;
import database.TimeSlotDB;
import database.WaitingListDB;
import controller.CourseRegController;

/**
 * Manager that handles all the boolean checks required for course registration and administrative functions
 * @author CALVIN TAN 
 * @version 1.0
 * @since 2020-11-22
 */
public class CheckController {
	
	/**
	 * Scanner for the Login Option
	 */
	private static Scanner x;

	/**
	 * Checks whether two indexes belong to the same course
	 * @param index1 The first index to be checked
	 * @param index2 The second index to be checked
	 * @return returns true if the two indexes belong to the same course
	 */
	public static boolean IndexesSameCourse(int index1,int index2)
	{
		String course1="";
		String course2="";
		course1 = CourseRegController.getCourseCodefromIndex(index1);
		course2 = CourseRegController.getCourseCodefromIndex(index2);
		if (course1.equals(course2))
		{
			return true;
		}
		return false;
	}
		
	/**
	 * Checks whether a particular course exists in the database
	 * @param courseCode The course code of the course that is to be checked
	 * @return returns true if the course exists in the database
	 */	
	public static boolean isCourseValid(String courseCode)
	{
		for (int i = 0; i < CourseDatabase.alr3.size(); i++ )
		{
			if (courseCode.equals(CourseDatabase.alr3.get(i).getcourseCode()))
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks whether a particular index number exists in the database
	 * @param index The index number that is to be checked
	 * @return returns true if there is a student in th waitlist for the index
	 */	
	public static boolean isIndexInWaitList(int index)
	{
		for (int i = 0; i<WaitingListDB.alr5.size();i++)
		{
			if (index == (WaitingListDB.alr5.get(i).getindex()))
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks whether a particular student is already on the wait list for an index
	 * @param matric The matriculation number of the student that is to be checked
	 * @param index The index number of the student that is to be checked
	 * @return returns true if the matriculation number is on the waitlist
	 */	
	public static boolean IsRecordInWaitList(String matric,int index)
	{
		for (int i = 0; i<WaitingListDB.alr5.size();i++)
		{
			if (matric.equals(WaitingListDB.alr5.get(i).getmatric()))
			{
				if (index == WaitingListDB.alr5.get(i).getindex())
				{
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Checks whether the index currently have vacancies (ie. if the vacancy is zero or not)
	 * @param index The index number that is to checked 
	 * @return returns true if there are no vacancies for the index
	 */	
	public static boolean isVacancyZero(int index)
	{
		for (int i = 0; i<IndexDB.alr2.size();i++)
		{
			if (index == (IndexDB.alr2.get(i).getindexNumber()))
			{
				if (IndexDB.alr2.get(i).getvacancy() == 0)
				{
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Checks whether a course registration record exists in the database
	 * @param matric The student's matriculation number
	 * @param courseCode The course code of the course that the student has registered for
	 * @return returns true if the record is found in the CourseReg database
	 */
	public static boolean checkRecordInCR(String matric, String courseCode)
	{
		boolean check = false;
		for (int i = 0; i < CourseRegDB.alr.size(); i++)
		{
			if (matric.equals(CourseRegDB.alr.get(i).getmatric()))
			{
				if (courseCode.equals(CourseRegDB.alr.get(i).getcourseCode()))
				{
					check=true;
				}
			}	
		}
		return check;
	}
	
	/**
	 * Checks whether a particular matriculation number exists in the database
	 * @param matric The matriculation number of the student that is to be checked
	 * @return returns true if the matriculation number exists in the database
	 */	
	public static boolean IsMatricExists(String matric)
	{
		for (int i = 0; i < StudentDB.alr4.size(); i++) 
		{
			if (matric.equals(StudentDB.alr4.get(i).getMatric()))
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks whether a index number belongs to a particular course
	 * @param courseCode The course code of the course to check the index number for
	 * @param index The index number that is to be checked
	 * @return returns true if the index belongs to the course
	 */
	public static Boolean checkIndexinCourse(String courseCode, int index) 
	{
		for (int i = 0; i < IndexDB.alr2.size(); i++)
		{
			if (courseCode.equals(IndexDB.alr2.get(i).getcourseCode()))
			{
				if (index == (IndexDB.alr2.get(i).getindexNumber()))
				{
					return true;
				}
			}
		}
		return false;		
	}
	
	/**
	 * Checks whether a index number exists in the database
	 * @param index The index number that is to be checked
	 * @return returns true if the index number exists in the database
	 */	
	public static boolean isIndexExists(int index)
	{
		for (int i = 0; i < IndexDB.alr2.size(); i++)
		{
			if (index == IndexDB.alr2.get(i).getindexNumber())
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Verifies the login credentials of the other student for the swapping of indexes
	 * @throws IOException : thrown if there are issues with saving the CourseReg object into the database
	 * @param username The student's username
	 * @param password The student's password
	 * @param filename The directory of the student database
	 * @return returns true if the student's login credentials are correct
	 */
	public static boolean verifyStudent2(String username, String password, String filename) throws IOException {
		boolean LoggedIn = false;
		boolean found = false;
		String tempUsername = "";
		String tempPassword = "";
		String matric = "0";
		String tempName = "";
		String tempMatric = "";
		String tempGender = "";
		String tempNationality = "";
		String tempSchool = "";
		String tempEmail = "";
		String tempAccessStart = "";
		String tempAccessEnd = "";
		String tempNotification = "";
		String sCurrentLine;
		BufferedReader br = null;

		try {
			x = new Scanner(new File(filename));
			x.useDelimiter("[|]");
			br = new BufferedReader(new FileReader(filename));
			// if file is empty throw IOException
			if (!x.hasNextLine()) {
				throw new IOException();
			}

			while (x.hasNext() && !found && (sCurrentLine = br.readLine()) != null) {
				tempUsername = x.next();
				tempPassword = x.next();
				tempName = x.next(); // third token
				tempMatric = x.next(); // fourth token
				tempGender = x.next(); // fifth token
				tempNationality = x.next(); // sixth token
				tempSchool = x.next(); // seventh token
				tempEmail = x.next(); // eighth token
				tempAccessStart = x.next(); // ninth token
				tempAccessEnd = x.next(); // tenth token

				if (tempUsername.trim().equals(username.toUpperCase().trim()) && tempPassword.trim().equals(password.trim())) {
					found = true;

					if (found == false) {
						LoggedIn = false;
					} else {
						return found;
					}
				}
			}
			x.close();
			br.close();

		} catch (IOException e) {

			if (LoggedIn == false) {
				File studFile = new File("student.txt");

				// call this when file not found
				if (!studFile.exists()) {
					System.out.println("Student File not Found");
				}
				// call this only when it exist and empty
				if (studFile.exists() && studFile.length() == 0) {
					System.out.println("Student File is empty");
				}
			}

		}

		return found;
	}
	
	/**
	 * Checks whether a student has already registered for a particular course
	 * @param matric The student's matriculation number
	 * @param courseCode The course code of the course that is to be checked
	 * @return returns true if the student is already registered for the course
	 */	
	public static Boolean checkRegistration(String courseCode, String matric)
	{	   
		for (int i = 0; i < CourseRegDB.alr.size(); i++) 
		{
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())) 
			{
				if (courseCode.equals(CourseRegDB.alr.get(i).getcourseCode()))
				{
					System.out.println("You have already registered for " + courseCode + "!");
					return true;
				}
			}
		}      
		return false;
	}
	
	/**
	 * Checks whether a student has already registered for a particular index
	 * @param matric The student's matriculation number
	 * @param index The index number that is to be checked
	 * @return returns true if the student is already registered for the index
	 */	
	public static Boolean checkRegistrationIndex(int index, String matric)
	{	   
		for (int i = 0; i < CourseRegDB.alr.size(); i++) 
		{
			if (matric.equals(CourseRegDB.alr.get(i).getmatric())) 
			{
				if (index==CourseRegDB.alr.get(i).getindex())
				{
					return true;
				}
			}
		}      
		return false;
	}
	
	/**
	 * Checks for timetable clash for the registering of a new course
	 * @param index The index number of the course that the student is registering for
	 * @return returns true if there is no timetable clash
	 */
	public static boolean checkClash(int index) 
	{
		String matric = LoginController.matric();
		int countadd = 0;
		String day1 = "";
		int start1 = 0;
		int end1 = 0;
		boolean check = true;
		int clashindex = 0;
		int finalclashindex = 0;

		for (int i = 0; i < CourseRegDB.alr.size(); i++) {
			if(CourseRegDB.alr.get(i).getmatric().equals(matric))
			{
				for (int j = 0; j < TimeSlotDB.alr6.size(); j++) {
					if (TimeSlotDB.alr6.get(j).getindexNumber() == CourseRegDB.alr.get(i).getindex())
					{ 
						day1 = TimeSlotDB.alr6.get(j).getdayOfweek();
						start1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getstartTime().trim());
						end1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getendTime().trim());
						clashindex = CourseRegDB.alr.get(i).getindex();
						for (int k = 0; k < TimeSlotDB.alr6.size(); k++)
						{
							if (TimeSlotDB.alr6.get(k).getindexNumber() == index)
							{								        	 
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}

								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex; 
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}	  
							}
						}
					}		

				}
			}
		}	
		if (check == false & countadd == 0)
		{
			System.out.println("\nClass Clash with your index " + finalclashindex +"!");
			countadd++;
		}
		if (check == true)
		{
			return check;
		}
		return check;
	}
	
	/**
	 * Checks for timetable clash for the changing of index number
	 * @param curindex The logged in student's current index number
	 * @param index The logged in student's new index number
	 * @return returns true if there is no timetable clash
	 */
	public static boolean checkChangeClash(int curindex, int index)
	{
		String matric = LoginController.matric();
		int count = 0;
		String day1 = "";
		int start1 = 0;
		int end1 = 0;
		boolean check = true;
		int clashindex = 0;
		int finalclashindex = 0;
		for (int i = 0; i < CourseRegDB.alr.size(); i++) {
			if(CourseRegDB.alr.get(i).getmatric().equals(matric))
			{
				for (int j = 0; j < TimeSlotDB.alr6.size(); j++) {
					if (TimeSlotDB.alr6.get(j).getindexNumber() == CourseRegDB.alr.get(i).getindex())
					{ 
						if (CourseRegDB.alr.get(i).getindex()!=curindex)
						{
							day1 = TimeSlotDB.alr6.get(j).getdayOfweek();
							start1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getstartTime().trim());
							end1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getendTime().trim());
							clashindex = CourseRegDB.alr.get(i).getindex();

						}
						for (int k = 0; k < TimeSlotDB.alr6.size(); k++)
						{
							if (TimeSlotDB.alr6.get(k).getindexNumber() == index)
							{	 
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}

								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex; 
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex = clashindex;
								}
							}
						}
					}		

				}
			}
		}

		if (check == false & count == 0)
		{
			System.out.println("\nClass Clash with your index " + finalclashindex +"!");
			count++;
		}
		if (check == true)
		{
			return check;
		}
		return check;
	}
	
	/**
	 * Checks for timetable clash for the swapping of indexes between two students
	 * @param matric2 The matriculation number of the student that the logged in student is swapping indexes with
	 * @param curindex The current index of the logged in student
	 * @param index The current index of the other student
	 * @return returns true if there is no timetable clash
	 */	
	public static boolean checkSwapClash(String matric2, int curindex, int index)
	{
		int count1 = 0;
		int count2 = 0;
		String matric = LoginController.matric();
		String day1 = "";
		int start1 = 0;
		int end1 = 0;
		boolean check = true;
		boolean check2 = true;
		boolean finalcheck = false;
		int clashindex1 = 0;
		int clashindex2 = 0;
		int finalclashindex1 = 0;
		int finalclashindex2 = 0;

		for (int i = 0; i < CourseRegDB.alr.size(); i++) {
			if(CourseRegDB.alr.get(i).getmatric().equals(matric))
			{
				for (int j = 0; j < TimeSlotDB.alr6.size(); j++) {
					if (TimeSlotDB.alr6.get(j).getindexNumber() == CourseRegDB.alr.get(i).getindex())
					{ 
						if (CourseRegDB.alr.get(i).getindex()!=curindex && CourseRegDB.alr.get(i).getindex()!=index)
						{
							day1 = TimeSlotDB.alr6.get(j).getdayOfweek();
							start1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getstartTime().trim());
							end1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getendTime().trim());
							clashindex1 = CourseRegDB.alr.get(i).getindex();

						}
						for (int k = 0; k < TimeSlotDB.alr6.size(); k++)
						{
							if (TimeSlotDB.alr6.get(k).getindexNumber() == index)
							{
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()))
								{
									check = false;
									finalclashindex1 = clashindex1;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex1 = clashindex1;
								}

								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check = false;
									finalclashindex1 = clashindex1;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex1 = clashindex1; 
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex1 = clashindex1;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex1 = clashindex1;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check = false;
									finalclashindex1 = clashindex1;
								} 
							}

						}
					}		

				}
			}
		}

		for (int i = 0; i < CourseRegDB.alr.size(); i++) {
			if(CourseRegDB.alr.get(i).getmatric().equals(matric2))
			{
				for (int j = 0; j < TimeSlotDB.alr6.size(); j++) {
					if (TimeSlotDB.alr6.get(j).getindexNumber() == CourseRegDB.alr.get(i).getindex())
					{ 
						if (CourseRegDB.alr.get(i).getindex()!=index && CourseRegDB.alr.get(i).getindex()!=curindex)
						{
							day1 = TimeSlotDB.alr6.get(j).getdayOfweek();
							start1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getstartTime().trim());
							end1 = Integer.parseInt(TimeSlotDB.alr6.get(j).getendTime().trim());
							clashindex2 = CourseRegDB.alr.get(i).getindex();
						}
						for (int k = 0; k < TimeSlotDB.alr6.size(); k++)
						{
							if (TimeSlotDB.alr6.get(k).getindexNumber() == curindex)
							{
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()))
								{
									check2 = false;
									finalclashindex2 = clashindex2;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check2 = false;
									finalclashindex2 = clashindex2;
								}

								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 == Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{
									check2 = false;
									finalclashindex2 = clashindex2;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check2 = false;
									finalclashindex2 = clashindex2; 
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check2 = false;
									finalclashindex2 = clashindex2;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check2 = false;
									finalclashindex2 = clashindex2;
								}
								if(day1.equals(TimeSlotDB.alr6.get(k).getdayOfweek()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()) & end1 > Integer.parseInt(TimeSlotDB.alr6.get(k).getstartTime().trim()) & start1 < Integer.parseInt(TimeSlotDB.alr6.get(k).getendTime().trim()))
								{	
									check2 = false;
									finalclashindex2 = clashindex2;
								}
							}

						}
					}		

				}
			}
		}
		if (check == false)
		{
			if(count1 == 0) {
				System.out.println("\nClass Clash with student 1's timetable! The index that is clashed with: " + finalclashindex1);
				count1++;
				count2++;
			}
		}
		if (check2 == false)
		{
			if(count2 == 0)
			{
				System.out.println("\nClass Clash with student 2's timetable! The index that is clashed with: " + finalclashindex2);
				count2++;
				count1++;
			}
		}
		if (check == true && check2 == true)
		{
			finalcheck = true;
		}
		return finalcheck;
	}
}
