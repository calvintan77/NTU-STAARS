package controller;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.mail.internet.AddressException;

import java.io.IOException;
import entity.Student;
import ui.*;

/**
 * A manager to validate the username and password of the user
 * @author TAN MEI XUAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class LoginController implements Runnable{

	/**
	 * Scanner for the database verifying
	 */
	private static Scanner x;
	
	/**
	 * Scanner for the Login Option
	 */
	private static Scanner sc = new Scanner(System.in);
	
	/**
	 * The matriculation number of the Logged in Student
	 */
	public static String m;
	
	/**
	 * A boolean variable used to facilitate the masking of password
	 */
	private boolean stop;

	/**
	 * Login Option for User
	 * @throws IOException : thrown if there are issues with accessing the database
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 * @throws ParseException : thrown if there are issues with parsing an object
	 */
	public static void LoginOption() throws IOException, AddressException, ParseException { 
		
		String accessRight = MainUI.domainUI(); // if choose Administrator, Student account cannot enter
		String username = "";
		String password = "";
		String admin = "ADMIN";
		String student = "STUDENT";
		String adminfilename = "admin.txt";
		String studfilename = "student.txt";
		
		System.out.print("\nEnter Username: ");
		username = sc.nextLine();
		System.out.print("Enter Password: ");
		String notHashedpassword = sc.nextLine();
		password = StudentController.getSecurePassword(notHashedpassword);
		//password = PasswordField.readPassword("Enter password: "); //THIS IS FOR MASKING BUT CANNOT BE TEST ON IDE
		//System.out.println("The password entered is: "+password); //DEBUGGING

		if (accessRight.equals(admin)) {
			verifyAdminLogin(username, password, adminfilename);
		} else if (accessRight.equals(student)) {
			m = verifyStudentLogin(username, password, studfilename);
			if (!m.equals("0")) {
				StudentUI.CallStudentUI();
			}
		}

	}

	/**
	 * Verifying User input with the Admin Database
	 * @param username The username input
	 * @param password The password input
	 * @param filename The filename for Admin
	 * @throws IOException : thrown if there are issues with accessing the database
	 * @throws ParseException : thrown if there are issues with parsing an object
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */
	public static void verifyAdminLogin(String username, String password, String filename) throws IOException, ParseException, AddressException {
		boolean found = false;
		String tempUsername = "";
		String tempPassword = "";
		boolean LoggedIn = false;
		
		try {
			x = new Scanner(new File(filename));
			x.useDelimiter("[|]");

			// if file is empty throw IOException
			if (!x.hasNextLine()) {
				throw new IOException();
			}

			while (x.hasNext() && !found) {
				tempUsername = x.next();
				tempPassword = x.next();
				if (tempUsername.trim().equals(username.trim()) && tempPassword.trim().equals(password.trim())) {
					found = true;
					LoggedIn = true;
					System.out.println("\nAdmin Logged in");
					AdminUI.CallAdminUI();
				}
			}
			x.close();
			// only do it if user not logged in
			if (LoggedIn == false) {
				System.out.println("\nWrong Username/Password. Please try Again");
				System.out.println("Domain used now is: ADMIN");
				System.out.println("Choose domain again..\n");
				MainUI.main(null);
			}

		} catch (IOException e) {

			if (LoggedIn == false) {
				File adminFile = new File("admin.txt");

				// call this when file not found
				if (!adminFile.exists()) {
					System.out.println("Admin File not Found");
				}
				// call this only when it exist and empty
				if (adminFile.exists() && adminFile.length() == 0) {
					System.out.println("Admin File is empty");
				}
			}

		}
	}

	/**
	 * Gets the matriculation number of the logged in student
	 * @return matriculation number
	 */
	public static String matric() {
		return m;
	}

	
	/**
	 * Verifying User input with the Student Database
	 * @param username The username input
	 * @param password The password input
	 * @param filename The filename for Student
	 * @return matric number if Student is Logged in
	 * @throws IOException : thrown if there are issues with accessing the database
	 * @throws ParseException : thrown if there are issues with parsing an object
	 * @throws AddressException : thrown if there are issues with sending the email to the student
	 */
	public static String verifyStudentLogin(String username, String password, String filename) throws IOException, ParseException, AddressException {
		boolean found = false;
		String tempUsername = "";
		String tempPassword = "";
		String matric = "0";
		String tempName = "";
		String tempMatric = "";
		String tempGender = "";
		String tempNationality = "";
		String tempSchool = "";
		String tempEmail = "";
		String tempAccessStart = "";
		String tempAccessEnd = "";
		String tempNotification = "";
		String sCurrentLine;
		BufferedReader br = null;
		boolean LoggedIn = false;

		try {
			x = new Scanner(new File(filename));
			x.useDelimiter("[|]");
		    br = new BufferedReader(new FileReader(filename));
			// if file is empty throw IOException
			if (!x.hasNextLine()) {
				throw new IOException();
			}
		
			while (x.hasNext() && !found && (sCurrentLine = br.readLine()) != null) {
				tempUsername = x.next();
				tempPassword = x.next();
				tempName = x.next(); // third token
				tempMatric = x.next(); // fourth token
				tempGender = x.next(); // fifth token
				tempNationality = x.next(); // sixth token
				tempSchool = x.next(); // seventh token
				tempEmail = x.next(); // eighth token
				tempAccessStart = x.next(); // ninth token
				tempAccessEnd = x.next(); // tenth token
				if (tempUsername.trim().equals(username.toUpperCase().trim()) && tempPassword.trim().equals(password.trim())) {
					found = true;
					LoggedIn = true;
					System.out.println("\nAccount found, now checking access time\n");
					Calendar now = Calendar.getInstance();

					// Converting Date to Calendar , so as to compare with the Calendar NOW
					Date dateAccessStart = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(tempAccessStart.trim());
					Calendar calendarAS = Calendar.getInstance();
					calendarAS.setTime(dateAccessStart);

					Date dateAccessEnd = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(tempAccessEnd.trim());
					Calendar calendarAE = Calendar.getInstance();
					calendarAE.setTime(dateAccessEnd);

					int compareAccessStart = calendarAS.compareTo(now);
					int compareAccessEnd = calendarAE.compareTo(now);

					if (compareAccessStart * compareAccessEnd > 0) {
						LoggedIn = false; // to break the cycle
						System.out.println("Sorry you are not allowed to access the portal now!");
						System.out.println("Please log in at your specified access period!");
						System.out.println("Your access time is from " + dateAccessStart + " to " + dateAccessEnd);
						System.out.println("");
						MainUI.CallMainUI();

					} else {
						matric = tempMatric.trim();
						System.out.println("Access Time Valid, Successfully Logged In.");
						LoggedIn = true;
						return matric;
					}
				}
			}
			x.close();
			br.close();
			// only do it if user not logged in
			if (LoggedIn == false) {
				System.out.println("\nWrong Username/Password. Try Again");
				System.out.println("Domain used now is: STUDENT");
				System.out.println("Choose domain again..\n");
				MainUI.main(null);
			}

		} catch (IOException | ParseException e) {

			if (LoggedIn == false) {
				File studFile = new File("student.txt");

				// call this when file not found
				if (!studFile.exists()) {
					System.out.println("Student File not Found");
				}
				// call this only when it exist and empty
				if (studFile.exists() && studFile.length() == 0) {
					System.out.println("Student File is empty");
				}
			}

		}

		return matric;
		
	}
    
	/**
     *@param prompt The prompt to display to the user
     *@return The password as entered by the user
     */
    public static String readPassword (String prompt) {
        LoginController et = new LoginController(prompt);
        Thread mask = new Thread(et);
        mask.start();

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String password = "";

        try {
            password = in.readLine();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        // stop masking
        et.stopMasking();
        // return the password entered by the user
        return password;
    }
    
    /**
     *@param  prompt displayed to the user
     */
    public LoginController(String prompt) {
        System.out.print(prompt);
    }

    /**
     * Begin masking...display asterisks (*)
     */
    public void run () {
        stop = true;
        while (stop) {
            System.out.print("\010*");
            try {
                Thread.currentThread().sleep(1);
            } catch(InterruptedException ie) {
                ie.printStackTrace();
            }
        }
    }

    /**
     * Instruct the thread to stop masking
     */
    public void stopMasking() {
        this.stop = false;
    }
}