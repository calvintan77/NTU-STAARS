package controller;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import database.CourseDatabase;

/**
 * Manager to handle all email related tasks
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-22
 */
public class MailController {
	
	/**
	 * The email that would be sent when the student is placed on waiting list
	 * @param to_email The email address that the email would be sent to
	 * @param index The course index that the student has been placed on waiting list
	 * @param courseCode The course code of the course index
	 * @param name The name of the user
	 * @throws AddressException thrown when a wrongly formatted address is encountered
	 */
	public static void SendWaitingListMail(String to_email, int index, String courseCode, String name) throws AddressException {
		final String email = "cz2004.from.email@gmail.com"; // valid email that would be used to send 
		final String password = "password14317!"; // valid password for email that would be used the send
		String coursename = "";
		String status = "Waiting List";
		
		System.out.println("\nSending email....");
		
		for (int i = 0; i < CourseDatabase.alr3.size(); i++)
		{
		     if (courseCode.equals(CourseDatabase.alr3.get(i).getcourseCode()))
		     {
		         coursename = CourseDatabase.alr3.get(i).getcourseName();
	    	 }
		}
		
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true"); //enable authentication
		props.put("mail.smtp.starttls.enable", "true"); // enable STARTTLS
		props.put("mail.smtp.host", "smtp.gmail.com"); // SMTP Host
		props.put("mail.smtp.port", "587"); // TLS Port
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, password);
			}
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("cz2004.from.email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to_email)); // to be added an email address
			message.setSubject("STARS Registration Waiting List"); // email subject
			message.setText(String.format("Dear %s, \n\nYou have been placed on the waiting list for the following course:\n\nCourse\tName\tIndex\tStatus\n%s\t%s\t%d\t%s\n\n You will receive an email when there is a new vacancy and will be automatically registered.\n\n Thank you!", name, courseCode, coursename, index, status)); // email content
			
			
			Transport.send(message);
			
			System.out.printf("Email has been sent to email address: %s", to_email);
			System.out.println("");
			
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * This email is sent when student from waiting list is registered into the course
	 * @param to_email The student's email address
	 * @param index The index number of the course that the student has been removed from its waiting list 
	 * @param courseCode The course code that the index number belongs to
	 * @param name The name of the student that the email is being sent to
	 * @throws AddressException thrown when a wrongly formatted address is encountered
	 */
	public static void SendRegisteredMail(String to_email, int index, String courseCode, String name) throws AddressException {
		final String email = "cz2004.from.email@gmail.com"; // valid email that would be used to send 
		final String password = "password14317!"; // valid password for email that would be used the send
		String coursename = "";
		String status = "Registered";
		
		System.out.println("\nSending email....");
		
		for (int i = 0; i < CourseDatabase.alr3.size(); i++)
		{
		     if (courseCode.equals(CourseDatabase.alr3.get(i).getcourseCode()))
		     {
		         coursename = CourseDatabase.alr3.get(i).getcourseName();
	    	 }
		}
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true"); //enable authentication
		props.put("mail.smtp.starttls.enable", "true"); // enable STARTTLS
		props.put("mail.smtp.host", "smtp.gmail.com"); // SMTP Host
		props.put("mail.smtp.port", "587"); // TLS Port
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, password);
			}
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("cz2004.from.email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to_email)); // to be added an email address
			message.setSubject("Successfully Registered from Waiting List"); // email subject
			message.setText(String.format("Dear %s, \n\nWe are pleased to inform you that you have been allocated the following course:\n\nCourse\tName\tIndex\tStatus\n%s\t%s\t%d\t%s\n\n Thank you!\n ", name, courseCode, coursename, index, status)); // email content
			
			Transport.send(message);
			
			System.out.println("Email has been sent to first person on waiting list");
			System.out.println("");
			
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	} 
}
