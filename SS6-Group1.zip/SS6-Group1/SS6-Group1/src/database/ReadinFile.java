package database;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * A class to facilitate the writing and reading of databases into the text file
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-18
 *
 */

public class ReadinFile {
	
	/**
	 * Writing fixed content into the text file
	 * @param filename The path of the text file
	 * @param data The data that is to be written into the text file
	 * @throws IOException : thrown if there are issues with writing into the text file
	 */
	public static void write(String filename, List data) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(filename));
		
		try {
			for (int i = 0; i < data.size(); i++)
			{
				out.println((String)data.get(i));
			}
			
		}
		finally {
			out.close();
		}
	}
	
	/**
	 * Reading the contents of the text file
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading from the text file
	 * @return returns an array list of the current database
	 */
	public static List read(String filename) throws IOException {
		List data = new ArrayList();
		Scanner sc = new Scanner(new FileInputStream(filename));
		
		try {
			while (sc.hasNextLine()) {
				data.add(sc.nextLine());
				}
			}
			finally {
				sc.close();
			}
		return data;
	}
}
