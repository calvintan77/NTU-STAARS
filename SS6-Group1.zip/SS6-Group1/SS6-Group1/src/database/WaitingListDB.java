package database;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import entity.WaitingList;


/**
 * A class to handle the wait list database
 * @author CALVIN TAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class WaitingListDB {
	
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
	public static final String SEPARATOR = "|";
	/**
	 * An array list to store the information of the registered courses
	 */
	public static ArrayList<WaitingList> alr5 = new ArrayList<WaitingList>();
	
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initWaitingList() throws IOException {
		String filename = "waitlist.txt";
		alr5 = readWaitingList(filename);}
	
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readWaitingList(String filename) throws IOException {
		ArrayList stringArray = (ArrayList)ReadinFile.read(filename); //read string from text file
		
		for (int i = 0; i < stringArray.size(); i++)
		{
			String st = (String)stringArray.get(i);
			StringTokenizer star = new StringTokenizer(st, SEPARATOR);	
			String matric = star.nextToken().trim(); 
			String index = star.nextToken().trim();
			int Index = Integer.parseInt(index.trim());
			
			WaitingList w = new WaitingList(matric, Index);
			// add to Student list
			alr5.add(w);
		}
		return alr5;
	}
	
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void save(String filename, ArrayList al) throws IOException {
		ArrayList alw = new ArrayList(); 
		
		for (int i = 0; i < al.size(); i++) {
			WaitingList w = (WaitingList)al.get(i);
			StringBuilder st = new StringBuilder();
			st.append(w.getmatric().trim());
			st.append(SEPARATOR);
			st.append(w.getindex());
			st.append(SEPARATOR);
			alw.add(st.toString());
		}		
		ReadinFile.write(filename, alw);
	}
	
	/**
	 * Deletes a WaitingList object from the database
	 * @param matric The matriculation number of the student
	 * @param index The index number of the course that is to be deleted from the wait list database
	 * @throws IOException : thrown if there are issues with updating the database
	 */
	public static void deleteWaitList(int index,String matric) throws IOException
	{
		try
		{
			BufferedReader file = new BufferedReader(new FileReader("waitlist.txt"));
			String line;
			String input = "";
			while ((line = file.readLine()) != null) 
			{
				if (line.contains(matric+"|"+index+"|"))
				{
					line = "";
				}
				if (!line.isEmpty()) {
					input += line + '\n';
				}
			}
			FileOutputStream File = new FileOutputStream("waitlist.txt");
			File.write(input.getBytes());
			file.close();
			File.close();
		}
		catch (Exception e)
		{
			System.out.println("Problem reading file.");
		}}
}