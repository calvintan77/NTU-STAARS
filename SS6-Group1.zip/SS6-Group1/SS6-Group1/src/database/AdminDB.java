package database;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import entity.Admin;

/**
 * A class to handle the administrator database
 * @author TAN MEI XUAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class AdminDB {
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
    public static final String SEPARATOR = "|";

	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
    public static ArrayList read(String filename) throws IOException {
        ArrayList stringArray = (ArrayList)ReadinFile.read(filename); //read string from text file
        ArrayList alr = new ArrayList(); // to store Students data

        for (int i = 0; i < stringArray.size(); i++)
        {
            String st = (String)stringArray.get(i);
            // get individual 'fields' of the string separated by SEPARATOR
            StringTokenizer star = new StringTokenizer(st, SEPARATOR);

            String username = star.nextToken().trim(); // first token
            String password = star.nextToken().trim(); // second token

            // create Student object from file data
            Admin ad = new Admin(username, password);
            // add to Student list
            alr.add(ad);
        }
        return alr;
    }
}

