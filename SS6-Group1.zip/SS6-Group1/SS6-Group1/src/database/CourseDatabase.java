package database;
import java.util.Scanner;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.List;

import entity.Course;
import entity.CourseReg;
import entity.Index;
import database.IndexDB;

/**
 * A class to handle the course database
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class CourseDatabase {
	
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */	
	public static final String SEPARATOR = "|";
	
	/**
	 * An array list to store the information of the registered courses
	 */	
	public static ArrayList<Course> alr3 = new ArrayList<Course>();
	
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initCourse() throws IOException {
		String filename = "course.txt";
		alr3 = readCourses(filename);}
	  
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readCourses(String filename) throws IOException {
	    
	//read String from text file
	ArrayList stringArray = (ArrayList)ReadinFile.read(filename);
	
	for (int j = 0; j < stringArray.size(); j++)
	{
		String st = (String)stringArray.get(j);
		// get individual fields of the string separated by SEPARATOR
		StringTokenizer star = new StringTokenizer(st, SEPARATOR);
	    String numberofIndex = star.nextToken().trim();
	    int numofIndex = Integer.parseInt(numberofIndex.trim());
	    String courseName = star.nextToken().trim(); 
		String courseCode = star.nextToken().trim(); 
		String Au = star.nextToken().trim();
		int au = Integer.parseInt(Au.trim());
		String school = star.nextToken().trim();
		Course c = new Course(numofIndex,courseName,courseCode,au,school);
		alr3.add(c);
		
	}
	return alr3;
}	    
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void saveCourses(String filename, List al) throws IOException {
	List alw = new ArrayList(); // to store Students data  
	for (int i = 0; i < al.size(); i++)
	{
		Course c = (Course)al.get(i);
		StringBuilder st = new StringBuilder();
		int index = c.getnumOfIndex();
		st.append(c.getnumOfIndex());
		st.append(SEPARATOR);
		st.append(c.getcourseName().trim());
		st.append(SEPARATOR);
		st.append(c.getcourseCode().trim());
		st.append(SEPARATOR);
		st.append(c.getAu());
		st.append(SEPARATOR);
		st.append(c.getschool().trim());
		st.append(SEPARATOR);
		alw.add(st.toString());	
		}
	    write(filename, alw);
	}
	    
	/**
	 * Writing fixed content into the text file
	 * @param fileName The path of the text file
	 * @param data The data that is to be written into the text file
	 * @throws IOException : thrown if there are issues with writing into the text file
	 */
	public static void write(String fileName, List data) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(fileName,true));
		try {
			for (int i = 0; i < data.size(); i++)
			{
				out.println((String)data.get(i));
			}
	    } finally {
	    	out.close();
	    }
	}
	    
	/**
	 * Reading the contents of the text file
	 * @param fileName The path of the text file
	 * @throws IOException : thrown if there are issues with reading from the text file
	 * @return returns an array list of the current database
	 */
	public static List read(String fileName) throws IOException {
		List data = new ArrayList();
	    Scanner scanner = new Scanner(new FileInputStream(fileName));
	    
	    try {
	    	while (scanner.hasNextLine()) {
	        data.add(scanner.nextLine());
	    	}
	    }
	    finally {
	    	scanner.close();
	    }
	    return data;
  }
	/**
	 * Removing a record from the database
	 * @param filepath The path of the text file
	 * @param removeTerm The term that is to be removed from the database
	 * @param positionOfTerm The position of the term in the database
	 * @param delimiter Delimiter used in the manipulation the database
	 */
	public static void removeRecord(String filepath, String removeTerm, int positionOfTerm, String delimiter) {
		int position = positionOfTerm -1;
		String tempFile = "temp.txt";
		File oldFile = new File(filepath);
		File newFile = new File(tempFile);
		String currentLine;
		String data[];
		try {
			FileWriter fw = new FileWriter(tempFile,true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			FileReader fr = new FileReader(filepath);
			BufferedReader br = new BufferedReader(fr);
			while((currentLine = br.readLine()) != null) {
				data = currentLine.split(delimiter);
				if(!data[position].equalsIgnoreCase(removeTerm)) {
					pw.println(currentLine);
				}
			}
			pw.flush();
			pw.close();
			fr.close();
			br.close();
			bw.close();
			fw.close();
			
			oldFile.delete();
			File dump = new File(filepath);
			newFile.renameTo(dump);
		}catch(Exception e) {
			System.out.println("IOException > " + e.getMessage());
		}
	}
	

}