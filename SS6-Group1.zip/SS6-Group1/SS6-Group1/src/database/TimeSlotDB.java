package database;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import entity.Student;
import entity.TimeSlot;


/**
 * A class to handle the time slot database
 * @author	GUO FEIYAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class TimeSlotDB {
	
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
	public static final String SEPARATOR = "|";
	/**
	 * An array list to store the information of the registered courses
	 */
	public static ArrayList<TimeSlot> alr6 = new ArrayList<TimeSlot>();
		
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initTimeSlot() throws IOException {
		String filename = "timeslot.txt";
		alr6 = readTimeslots(filename);}
	
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readTimeslots(String filename) throws IOException {
	    
	//read String from text file
	ArrayList stringArray = (ArrayList) read(filename);
	
	for (int j = 0; j < stringArray.size(); j++)
	{
		String st = (String)stringArray.get(j);
		// get individual fields of the string separated by SEPARATOR
		StringTokenizer star = new StringTokenizer(st, SEPARATOR);
		String index = star.nextToken().trim();
		int Index = Integer.parseInt(index.trim());
		String typeOfLesson = star.nextToken().trim();
	    String dayOfWeek = star.nextToken().trim();
	    String venue = star.nextToken().trim();
	    String startTime = star.nextToken().trim();
	    String endTime = star.nextToken().trim();
	    TimeSlot ts = new TimeSlot(Index,typeOfLesson,dayOfWeek,venue,startTime,endTime);
	    alr6.add(ts);
	}  
	return alr6;
	}
	
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void saveTimeslots(String filename, List al) throws IOException {
	List alw = new ArrayList(); // to store Students data  
	for (int i = 0; i < al.size(); i++)
	{
		TimeSlot ts = (TimeSlot)al.get(i);
		StringBuilder st = new StringBuilder();
		st.append(ts.getindexNumber());
		st.append(SEPARATOR);
		st.append(ts.gettypeOfLesson());
		st.append(SEPARATOR);
		st.append(ts.getdayOfweek());
		st.append(SEPARATOR);
		st.append(ts.getvenue());
		st.append(SEPARATOR);
		st.append(ts.getstartTime());
		st.append(SEPARATOR);
		st.append(ts.getendTime());
		st.append(SEPARATOR);
		alw.add(st.toString());
	}
		write(filename, alw);
	}
	    
	/**
	 * Writing fixed content into the text file
	 * @param fileName The path of the text file
	 * @param data The data that is to be written into the text file
	 * @throws IOException : thrown if there are issues with writing into the text file
	 */
	public static void write(String fileName, List data) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(fileName,true));
		try {
			for (int i = 0; i < data.size(); i++)
			{
				out.println((String)data.get(i));
			}
	    } finally {
	    	out.close();
	    }
	}
	    
	/**
	 * Reading the contents of the text file
	 * @param fileName The path of the text file
	 * @throws IOException : thrown if there are issues with reading from the text file
	 * @return returns an array list of the current database
	 */
	public static List read(String fileName) throws IOException {
		List data = new ArrayList();
	    Scanner scanner = new Scanner(new FileInputStream(fileName));
	    
	    try {
	    	while (scanner.hasNextLine()) {
	        data.add(scanner.nextLine());
	    	}
	    }
	    finally {
	    	scanner.close();
	    }
	    return data;
  }

}
