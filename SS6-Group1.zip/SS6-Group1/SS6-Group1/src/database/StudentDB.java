package database;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

import entity.Student;

/**
 * A class to handle the student database
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class StudentDB {
	
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
	public static final String SEPARATOR = "|";
	/**
	 * An array list to store the information of the registered courses
	 */
	public static ArrayList<Student> alr4 = new ArrayList<Student>();
	
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initStudent() throws IOException {
		String filename = "student.txt";
		alr4 = readStudent(filename);
	}
		
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readStudent(String filename) throws IOException {
		ArrayList stringArray = (ArrayList)ReadinFile.read(filename); //read string from text file
		
		for (int i = 0; i < stringArray.size(); i++)
		{
			String st = (String)stringArray.get(i);
			// get individual 'fields' of the string separated by SEPARATOR
			StringTokenizer star = new StringTokenizer(st, SEPARATOR);
			
			String username = star.nextToken().trim(); // first token
			String password = star.nextToken().trim(); // second token
			String name = star.nextToken().trim(); // third token
			String matric = star.nextToken().trim(); // fourth token
			String gender = star.nextToken().trim(); // fifth token
			String nationality = star.nextToken().trim(); // sixth token
			String school = star.nextToken().trim(); // seventh token
			String email = star.nextToken().trim(); // eighth token
			String accessStart = star.nextToken().trim(); // find out how to input calendar into tokenizer
			String accessEnd = star.nextToken().trim();
			
			// create Student object from file data
			Student s = new Student(username, password, name, matric, gender, nationality, school, email, accessStart, accessEnd);
			// add to Student list
			alr4.add(s);
		}
		return alr4;
	}
	
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void save(String filename, ArrayList al) throws IOException {
		ArrayList alw = new ArrayList(); // to store students data
		
		for (int i = 0; i < al.size(); i++) {
			Student s = (Student)al.get(i);
			StringBuilder st = new StringBuilder();
			st.append(s.getUsername().trim());
			st.append(SEPARATOR);
			st.append(s.getPassword().trim());
			st.append(SEPARATOR);
			st.append(s.getName().trim());
			st.append(SEPARATOR);
			st.append(s.getMatric().trim());
			st.append(SEPARATOR);
			st.append(s.getGender().trim());
			st.append(SEPARATOR);
			st.append(s.getNationality().trim());
			st.append(SEPARATOR);
			st.append(s.getSchool().trim());
			st.append(SEPARATOR);
			st.append(s.getEmail().trim());
			st.append(SEPARATOR);
			st.append(s.getAccessStart());
			st.append(SEPARATOR);
			st.append(s.getAccessEnd());
			st.append(SEPARATOR);
			alw.add(st.toString());
		}		
		ReadinFile.write(filename, alw);
	}
	
	/**
	 * Clears the text file
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading from the text file
	 */
	public static void clearTheFile(String filename) throws IOException {
        FileWriter fwOb = new FileWriter(filename, false); 
        PrintWriter pwOb = new PrintWriter(fwOb, false);
        pwOb.flush();
        pwOb.close();
        fwOb.close();
    }
}
