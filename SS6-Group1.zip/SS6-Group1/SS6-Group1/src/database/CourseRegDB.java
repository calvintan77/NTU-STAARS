package database;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import entity.CourseReg;

/**
 * A class to handle the course registration database
 * @author CALVIN TAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class CourseRegDB {
	/**
	 * An array list to store the information of the registered courses
	 */
	public static ArrayList<CourseReg> alr = new ArrayList<CourseReg>();
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
	public static final String SEPARATOR = "|";
	
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initCourseReg() throws IOException {
		String filename = "CourseReg.txt";
		alr = readCourseReg(filename); //read string from text file
	}
	
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readCourseReg(String filename) throws IOException {
		ArrayList stringArray = (ArrayList)ReadinFile.read(filename);
		
		for (int i = 0; i < stringArray.size(); i++)
		{
			String st = (String)stringArray.get(i);
			// get individual 'fields' of the string separated by SEPARATOR
			StringTokenizer star = new StringTokenizer(st, SEPARATOR);			
			String courseCode = star.nextToken().trim(); // first token
			String matric = star.nextToken().trim();
			String index = star.nextToken().trim();// second token
			int Index = Integer.parseInt(index.trim());// third token
			
			// create Student object from file data
			CourseReg c = new CourseReg(courseCode, matric, Index);
			// add to Student list
			alr.add(c);
		}
		return alr;
	}
	
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void save(String filename, ArrayList al) throws IOException {
		ArrayList alw = new ArrayList(); // to store students data
		
		for (int i = 0; i < al.size(); i++) {
			CourseReg c = (CourseReg)al.get(i);
			StringBuilder st = new StringBuilder();
			st.append(c.getcourseCode().trim());
			st.append(SEPARATOR);
			st.append(c.getmatric().trim());
			st.append(SEPARATOR);
			st.append(c.getindex());
			st.append(SEPARATOR);
			alw.add(st.toString());
		}		
		ReadinFile.write(filename, alw);
	}
	
	/**
	 * Deletes a CourseReg object from the database
	 * @param matric The matriculation number of the student
	 * @param index The index number of the course that is to be deleted from the registered courses database
	 * @throws IOException : thrown if there are issues with updating the database
	 */
	public static void deleteCourseReg(int index,String matric) throws IOException
	{
		String courseCode="";
		try
		{
			BufferedReader file = new BufferedReader(new FileReader("CourseReg.txt"));
			String line;
			String input = "";
			for (int i = 0; i < IndexDB.alr2.size(); i++)
			{
				if (IndexDB.alr2.get(i).getindexNumber()== index)
				{
					courseCode = IndexDB.alr2.get(i).getcourseCode();
				}
			}
			while ((line = file.readLine()) != null) 
			{
				if (line.contains(courseCode+"|"+matric+"|"+index+"|"))
				{
					line = "";
				}
				if (!line.isEmpty()) {
					input += line + '\n';
				}

			}
			FileOutputStream File = new FileOutputStream("CourseReg.txt");
			File.write(input.getBytes());
			file.close();
			File.close();
		}
		catch (Exception e)
		{
			System.out.println("Problem reading file.");
		}}
}

