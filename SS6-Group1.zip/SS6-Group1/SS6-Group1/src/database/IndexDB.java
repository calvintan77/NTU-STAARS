package database;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.List;

import entity.Index;

/**
 * A class to handle the index database
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-18
 *
 */

public class IndexDB {
	
	/**
	 * A separator variable to facilitate the reading and saving of the database
	 */
	public static final String SEPARATOR = "|";
	/**
	 * An array list to store the information of the registered courses
	 */
	public static ArrayList<Index> alr2 = new ArrayList<Index>();
	  
	/**
	 * Initializes the database
	 * @throws IOException : thrown if there are issues with reading the database
	 */
	public static void initIndex() throws IOException {
		String filename = "index.txt";
		alr2 = readIndexes(filename);}
	
	/**
	 * Reads in the text file into the database
	 * @param filename The path of the text file
	 * @throws IOException : thrown if there are issues with reading in the text file into the database
	 * @return returns an array list of the current database
	 */
	public static ArrayList readIndexes(String filename) throws IOException {
		ArrayList stringArray = (ArrayList)ReadinFile.read(filename);
	
	for (int j = 0; j < stringArray.size(); j++)
	{
		String st = (String)stringArray.get(j);
		// get individual fields of the string separated by SEPARATOR
		StringTokenizer star = new StringTokenizer(st, SEPARATOR);
		String courseCode = star.nextToken().trim();
	    String numberOfTimeSlot = star.nextToken().trim();
	    int numOfTimeSlot = Integer.parseInt(numberOfTimeSlot.trim());
		String index = star.nextToken().trim();
		String vacancy = star.nextToken().trim(); 
		int Index = Integer.parseInt(index.trim());
		int Vacancy = Integer.parseInt(vacancy.trim());
	    Index in = new Index(courseCode,Index,Vacancy,numOfTimeSlot);
	    alr2.add(in);
	}  
	return alr2;
	}
	 
	/**
	 * Saves the database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void saveIndexes(String filename, List al) throws IOException {
	List alw = new ArrayList(); // to store Students data  
	for (int i = 0; i < al.size(); i++)
	{
		Index in = (Index)al.get(i);
		StringBuilder st = new StringBuilder();
		st.append(in.getcourseCode());
		st.append(SEPARATOR);
		st.append(in.getnumOfTimeslot());
		st.append(SEPARATOR);
		st.append(in.getindexNumber());
		st.append(SEPARATOR);
		st.append(in.getvacancy());
		st.append(SEPARATOR);
		alw.add(st.toString());
	}
		write(filename, alw);
	}
	
	/**
	 * Updating the new database into the text file
	 * @param filename The path of the text file
	 * @param al The array list to read from
	 * @throws IOException : thrown if there are issues with saving the database
	 */
	public static void updateIndexes(String filename, List al) throws IOException {
	List alw = new ArrayList(); // to store Students data  
	for (int i = 0; i < al.size(); i++)
	{
		Index in = (Index)al.get(i);
		StringBuilder st = new StringBuilder();
		st.append(in.getcourseCode());
		st.append(SEPARATOR);
		int index = in.getnumOfTimeslot();
		st.append(in.getnumOfTimeslot());
		st.append(SEPARATOR);
		st.append(in.getindexNumber());
		st.append(SEPARATOR);
		st.append(in.getvacancy());
		st.append(SEPARATOR);
		alw.add(st.toString());
	}
		ReadinFile.write(filename, alw);
	}
	
	/**
	 * Writing fixed content into the text file
	 * @param fileName The path of the text file
	 * @param data The data that is to be written into the text file
	 * @throws IOException : thrown if there are issues with writing into the text file
	 */
	public static void write(String fileName, List data) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(fileName,true));
		try {
			for (int i = 0; i < data.size(); i++)
			{
				out.println((String)data.get(i));
			}
	    } finally {
	    	out.close();
	    }
	}
	    
	/**
	 * Reading the contents of the text file
	 * @param fileName The path of the text file
	 * @throws IOException : thrown if there are issues with reading from the text file
	 * @return returns an array list of the current database
	 */
	public static List read(String fileName) throws IOException {
		List data = new ArrayList();
	    Scanner scanner = new Scanner(new FileInputStream(fileName));
	    
	    try {
	    	while (scanner.hasNextLine()) {
	        data.add(scanner.nextLine());
	    	}
	    }
	    finally {
	    	scanner.close();
	    }
	    return data;
  }

}