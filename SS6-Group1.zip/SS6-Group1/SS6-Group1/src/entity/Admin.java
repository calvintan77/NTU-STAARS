package entity;

/**
 * Represents Admin user
 * @author TAN MEI XUAN
 * @version 1.0
 * @since 2020-11-18
 *
 */
public class Admin {
    /**
     * The username of this admin
     */
    private String admin_username;
    
    /**
     * The password of this admin
     */
    private String admin_password;

    /**
     * Creates a new Admin with the given username and password
     * @param username This Admin's username
     * @param password This Admin's password
     */
    public Admin(String username, String password) {
        this.admin_username = username;
        this.admin_password = password;

    }

    /**
     * Gets the password of the admin
     * @return this admin's password
     */
    public String getAdmin_password() {
        return admin_password;
    }

    /**
     * Changes the Admin's password
     * @param admin_password This admin's new password
     */
    public void setAdmin_password(String admin_password) {
        this.admin_password = admin_password;
    }

    /**
     * Gets the username of the admin
     * @return this admin's username
     */
    public String getAdmin_username() {
        return admin_username;
    }

    /**
     * Changes the Admin's username
     * @param admin_username This admin's username
     */
    public void setAdmin_username(String admin_username) {
        this.admin_username = admin_username;
    }
}
