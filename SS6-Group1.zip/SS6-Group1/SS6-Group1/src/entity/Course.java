package entity;
import java.util.ArrayList;

/**
 * Represents the courses that are available
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-21
 */
public class Course {
	/**
	 * The name of the course
	 */
	private String courseName;
	/**
	 * The course code of the course
	 */
	private String courseCode;
	/**
	 * The number of Academic Units the course fulfills
	 */
	private int au;
	/**
	 * The faculty that provides this course
	 */
	private String school;
	/**
	 * The indexes that the course has
	 */
    private ArrayList<String> indexes;
    /**
     * The number of indexes that course has
     */
	private int numOfIndex;
	
	/**
	 * Creates a Course Object
	 */
	public Course() {}
	
	/**
	 * Add course with the given course name, course code, number of AUs, number of Indexes and the faculty the course belongs to
	 * @param numOfIndex The number of indexes that the course object have
	 * @param courseName The name of the course object
	 * @param courseCode The course code of the course object
	 * @param au The number of academic units of the course object
	 * @param school The school that the course object belong to
	 */
	public Course(int numOfIndex, String courseName, String courseCode, int au, String school) {
		this.courseName = courseName;
		this.courseCode = courseCode;
		this.au = au;
		this.school = school;
		this.numOfIndex = numOfIndex;
	}
	
	/**
	 * Gets the name of the course
	 * @return this course's name
	 */
	public String getcourseName() {
		return courseName;
	}
	/**
	 * Gets the code of the course
	 * @return this course's code
	 */
	public String getcourseCode() {
		return courseCode;
	}
	/**
	 * Gets the number of Academic Units that the course fulfills
	 * @return this course's number of academic units
	 */
	public int getAu() {
		return au;
	}
	/**
	 * Gets the faculty the course belongs to
	 * @return the faculty that this course belongs to
	 */
	public String getschool() {
		return school;
	}
	/**
	 * Gets the number of indexes the course has
	 * @return the number of indexes this course has
	 */
	public int getnumOfIndex() {
		return numOfIndex;
	}
	/**
	 * Adds a new index to the Course Object's current list of index
	 * @param indexId The new index of the Course Object
	 */
    public void addIndex(String indexId) {
        this.indexes.add(indexId);
	}
	/**
	 * Changes/sets the name of the Course Object
	 * @param newcourseName This Course Object's name
	 */
	public void setCourseName(String newcourseName) {
		courseName = newcourseName;
	}
	/**
	 * Changes/sets the code of the Course Object
	 * @param newcourseCode This Course Object's course code
	 */
	public void setcourseCode(String newcourseCode) {
		courseCode = newcourseCode;
	}
	/**
	 * Changes/sets the number of academic units of the Course Object
	 * @param newau This Course Object's number of academic units
	 */
	public void setAu(int newau) {
		au = newau;
	}
	/**
	 * Changes/sets the faculty that the Course Object belongs to
	 * @param newschool This Course Object's faculty
	 */
	public void setschool(String newschool) {
		school = newschool;
	}
}