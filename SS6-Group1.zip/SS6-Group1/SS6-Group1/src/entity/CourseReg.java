package entity;
/**
 * Represents Courses Registered by Student
 * @author CALVIN TAN
 * @version 1.0
 * @since 2020-11-21
 */
public class CourseReg
{
    /**
     * The matriculation number of the student registered in the course
     */
	private String matric;
    /**
     * The course code of the course that the student has registered in
     */
	private String courseCode;
    /**
     * The index number of the index that the student has registered in
     */
	private int index;
    /**
     * Creates a CourseReg object
     */
	public CourseReg() {}
    /**
     * Registers student for a course with the given course code, matriculation number and index number
     * @param courseCode This CourseReg Object's course code
     * @param matric This CourseReg Object's matriculation number
     * @param index This CourseReg Object's index number
     */
	public CourseReg(String courseCode, String matric, int index) 
	{
		this.courseCode = courseCode;
		this.matric = matric;
		this.index = index;
	}
    /**
     * Gets the course code of the course the student has registered for
     * @return this student's course code
     */
	public String getcourseCode() {
		return courseCode;
	}
    /**
     * Gets the matriculation number of the student
     * @return this student's matriculation number
     */
	public String getmatric() {
		return matric;
	}
    /**
     * Gets the index number of the course the student has registered for
     * @return this student's index number
     */
	public int getindex() {
		return index;
	}
    /**
     * Changes/sets the course code of the CourseReg Object
     * @param newcourseCode This CourseReg Object's new course code
     */
	public void setcourseCode(String newcourseCode) {
		courseCode = newcourseCode;
	}
    /**
     * Changes/sets the index number of the CourseReg Object
     * @param newindex This CourseReg Object's new index number
     */
	public void setindex(int newindex) {
		index = newindex;
	}
    /**
     * Changes/sets the matriculation number of the CourseReg Object
     * @param newmatric This CourseReg Object's new matriculation number
     */
	public void setmatric(String newmatric) {
		matric = newmatric;
	}
}