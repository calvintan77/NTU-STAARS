package entity;

/**
 * Represents the different indexes of each course
 * @author GUO FEIYAN
 * @version 1.0
 * @since 2020-11-21
 */
public class Index {
	/**
	 * courseCode that index belongs to
	 */
	private String courseCode;
	/**
	 * The number that identifies the index
	 */
	private int indexNumber;
	/**
	 * The number of vacancies in the index
	 */
	private int vacancy;
	/**
	 * The number of lesson time slots the index has
	 */
	private int numOfTimeslot;

	/**
	 * Adds a new Index with the course code the index belongs to, the index number, the number of vacancies and the number of lesson time slots
	 * @param courseCode The course code that the index object belongs to
	 * @param indexNumber The index number of the index object
	 * @param vacancy The number of vacancies that the index object have
	 * @param numOfTimeslot The number of time slots that the index object have
	 */
	public Index(String courseCode, int indexNumber, int vacancy, int numOfTimeslot) {
		this.courseCode = courseCode;
		this.indexNumber = indexNumber;
		this.vacancy = vacancy;
		this.numOfTimeslot = numOfTimeslot;
	}
	
	/**
	 * Gets the course code that the index belongs to
	 * @return this index's course code
	 */
	public String getcourseCode() {
		return courseCode;
	}
	/**
	 * Gets the index's identity number
	 * @return this index's identity number
	 */
	public int getindexNumber() {
		return indexNumber;
	}
	/**
	 * Gets the index's number of vacancies
	 * @return this index's number of vacancies
	 */
	public int getvacancy() {
		return vacancy;
	}
	/**
	 * Gets the index's number of time slots
	 * @return this index's number of time slots
	 */
	public int getnumOfTimeslot() {
		return numOfTimeslot;
	}
	/**
	 * Changes/sets the Index Object's course code
	 * @param newcourseCode This Index Object's course code
	 */
	public void setcourseCode(String newcourseCode) {
		courseCode = newcourseCode;
	}
	/**
	 * Changes/sets the Index Object's index number
	 * @param newindexNumber This Index Object's number
	 */
	public void setindexNumber(int newindexNumber) {
		indexNumber = newindexNumber;
	}
	/**
	 * Changes/sets the Index Object's number of vacancies
	 * @param newvacancy This Index Object's number of vacancies
	 */
	public void setvacancy(int newvacancy) {
		vacancy = newvacancy;
	}
}
