package entity;
/**
 * Represents students that are placed on the wait list for the different indexes
 * @author CALVIN TAN
 * @version 1.0
 * @since 2020-11-21
 *
 */
public class WaitingList
{
    /**
     * The matriculation number of the student placed on the wait list
     */
	private String matric;
    /**
     * The index number of the student placed on the wait list 
     */
	private int index;
    /**
     * Creates a WaitingList object
     */
	public WaitingList() {}
    /**
     * Adds student to the wait list with the given matriculation number and index number
     * @param matric This student's matriculation number
     * @param index This student's index number
     */
	public WaitingList(String matric, int index) 
	{
		this.matric = matric;
		this.index = index;
	}
    /**
     * Gets the matriculation number of the student
     * @return this student's matriculation number
     */
	public String getmatric() {
		return matric;
	}
    /**
     * Gets the index number of the student
     * @return this student's index number
     */
	public int getindex() {
		return index;
	}
    /**
     * Changes/sets the matriculation number of the WaitingList object
     * @param newmatric This WaitingList object's new matriculation number
     */
	public void setmatric(String newmatric) {
		matric = newmatric;
	}
    /**
     * Changes/sets the index number of the WaitingList object
     * @param newindex This WaitingList object's new index number
     */
	public void setindex(int newindex) {
		index = newindex;
	}

}