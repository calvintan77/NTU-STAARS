package entity;

/**
 * Represents Students that are added
 * @author CHEAH MUN YAN GRACE
 * @version 1.0
 * @since 2020-11-21
 */
public class Student {
	/**
	 * User name for student's account
	 */
	private String username;
	/**
	 * Password that will be used for student's account
	 */
	private String password;
	/**
	 * The name of the student
	 */
	private String name;
	/** 
	 * The matriculation number of the student that is unique
	 */
	private String matric;
	/**
	 * The gender of the student
	 */
	private String gender;
	/**
	 * The nationality of the student
	 */
	private String nationality;
	/**
	 * The faculty that the student is enrolled in
	 */
	private String school;
	/**
	 * The email of the student
	 */
	private String email;
	/**
	 * The start of the access time period the student is allowed to use STARS
	 */
	private String accessStart;
	/**
	 * The end of the access time period the student is allowed to use STARS
	 */
	private String accessEnd;
	
	/**
	 * Create a Student object
	 */
	public Student() {}
	/**
	 * Adds a new student with the following parameters
	 * @param username The Student Object's account user name
	 * @param password The Student Object's account password
	 * @param name The Student Object's name
	 * @param matric The Student Object's matriculation number
	 * @param gender The Student Object's gender
	 * @param nationality The Student Object's nationality
	 * @param school The Student Object's school
	 * @param email The Student Object's email
	 * @param accessStart The start of Student Object's access time period 
	 * @param accessEnd The end of Student Object's access time period
	 */
	public Student(String username, String password, String name, String matric, String gender, String nationality, String school, String email, String accessStart, String accessEnd)
	{
		this.username = username;
		this.password = password;
		this.name = name;
		this.matric = matric;
		this.gender = gender;
		this.nationality = nationality;
		this.school = school;
		this.email = email;
		this.accessEnd = accessEnd;
		this.accessStart = accessStart;
	}
	
	/**
	 * Get the student's name
	 * @return this student's name
	 */
	public String getName() {return name;}
	/**
	 * Changes/sets the name of the Student Object
	 * @param name This Student Object's name
	 */
	public void setName(String name) {this.name = name;}
	/**
	 * Get the student's account username
	 * @return this student's account username
	 */
	public String getUsername() {return username;}
	/**
	 * Changes/sets the username of the Student Object's account
	 * @param username This Student Object's account username
	 */
	public void setUsername(String username) {this.username = username;}
	/**
	 * Get the student's account password
	 * @return this student's account password
	 */
	public String getPassword() {return password;}
	/**
	 * Changes/sets the password of the Student Object's account
	 * @param password This Student Object's account password
	 */
	public void setPassword(String password) {this.password = password;}
	/**
	 * Gets the student's email address
	 * @return this student's email address
	 */
	public String getEmail() {return email;}
	/**
	 * Changes/sets the Student Object's email address
	 * @param email This Student Object's email address
	 */
	public void setEmail(String email) {this.email = email;}
	/**
	 * Gets the student's matriculation number
	 * @return this student's matriculation number
	 */
	public String getMatric() {return matric;}
	/**
	 * Changes/sets the Student Object's matriculation number
	 * @param matric This Student Object's matriculation number
	 */
	public void setMatric(String matric) {this.matric = matric;}
	/**
	 * Gets the student's gender
	 * @return this student's gender
	 */
	public String getGender() {return gender;}
	/**
	 * Changes/sets the Student Object's gender
	 * @param gender This Student Object's gender
	 */
	public void setGender(String gender) {this.gender = gender;}
	/**
	 * Gets the student's nationality
	 * @return this student's nationality
	 */
	public String getNationality() {return nationality;}
	/**
	 * Changes/sets the Student Object's nationality
	 * @param nationality This Student Object's nationality
	 */
	public void setNationality(String nationality) {this.nationality = nationality;}
	/**
	 * Gets the student's faculty
	 * @return this student's faculty
	 */
	public String getSchool() {return school;}
	/**
	 * Changes/sets the Student Object's school
	 * @param school This Student Object's school
	 */
	public void setSchool(String school) {this.school = school;}
	/**
	 * Gets the start of the student's access time period to use the STARS application
	 * @return the start of this student's access time period
	 */
	public String getAccessStart() {return accessStart;}
	/**
	 * Changes/sets the start of the Student Object's access time period
	 * @param accessStart The start of this Student Object's access time period
	 */
	public void setAccessStart(String accessStart) {this.accessStart = accessStart;}
	/**
	 * Gets the end of the student's access time period
	 * @return the end of this student's access time period
	 */
	public String getAccessEnd() {return accessEnd;}
	/**
	 * Changes/sets the end of the Student Object's access time period
	 * @param accessEnd The end of this Student Object's access time period
	 */
	public void setAccessEnd(String accessEnd) {this.accessEnd = accessEnd;}	
}

