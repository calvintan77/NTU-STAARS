package entity;

/**
 * Represents the lesson time slots
 * @author GUO FEIYAN
 *
 */
public class TimeSlot {
	/**
	 * The index number that the time slot belongs to
	 */
	private int indexNumber;
	/**
	 * The type of lesson in that time slot
	 */
	private String typeOfLesson;
	/**
	 * The day the time slot is in
	 */
	private String dayOfWeek;
	/**
	 * The venue of the lesson in that time slot
	 */
	private String venue;
	/**
	 * The start time of the time slot in 24 hour format
	 */
	private String startTime;
	/**
	 * The end time of the time slot in 24 hour format
	 */
	private String endTime;
	
	/**
	 * Add a new lesson time slot for each index with the following parameters
	 * @param indexNumber The index number that the timeslot object belongs to
	 * @param typeOfLesson The type of lesson of the timeslot object
	 * @param dayOfWeek The day of lesson of the timeslot object
	 * @param venue The venue of lesson of the timeslot object
	 * @param startTime The start time of the lesson of the timeslot object
	 * @param endTime The end time of the lesson of the timeslot object
	 */
	public TimeSlot(int indexNumber,String typeOfLesson, String dayOfWeek, String venue, String startTime, String endTime) {
		this.indexNumber = indexNumber;
		this.typeOfLesson = typeOfLesson;
		this.dayOfWeek = dayOfWeek;
		this.venue = venue;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	/**
	 * Gets the index number that the time slot belongs in
	 * @return the index number of this time slot
	 */
	public int getindexNumber() {
		return indexNumber;
	}
	/**
	 * Gets the type of lesson in the time slot of a specific index number
	 * @return the type of lesson for this time slot with the specific index number
	 */
	public String gettypeOfLesson() {
		return typeOfLesson;
	}
	/**
	 * Gets the day of the time slot of a specific index number 
	 * @return the day of this time slot with the specific index number
	 */
	public String getdayOfweek() {
		return dayOfWeek;
	}
	/**
	 * Gets the venue of the lesson in that time slot for a specific index number
	 * @return the venue of this lesson time slot for the specific index number
	 */
	public String getvenue() {
		return venue;
	}
	/**
	 * Gets the start time of the time slot for a specific index number's lesson
	 * @return the start time of this time slot for the specific index number's lesson
	 */
	public String getstartTime() {
		return startTime;
	}
	/**
	 * Gets the end time of the time slot for a specific index number's lesson
	 * @return the end time of this time slot for the specific index number's lesson
	 */
	public String getendTime() {
		return endTime;
	}
	/**
	 * Updates/sets the index number that the time slot belongs to
	 * @param newindexNumber The index number that this time slot belongs to
	 */
	public void setindexNumber(int newindexNumber) {
		indexNumber = newindexNumber;
	}
	/**
	 * Updates/sets the type of lesson that the time slot is being used for
	 * @param newtypeOfLesson The type of lesson for this time slot
	 */
	public void settypeOfLesson(String newtypeOfLesson) {
		typeOfLesson = newtypeOfLesson;
	}
	/**
	 * Updates/sets the day of the week for the time slot
	 * @param newdayOfWeek The day of the week for this time slot
	 */
	public void setdayOfWeek(String newdayOfWeek) {
		dayOfWeek = newdayOfWeek;
	}
	/**
	 * Updates/sets the venue for the time slot
	 * @param newvenue The venue for this time slot
	 */
	public void setVenue(String newvenue) {
		venue = newvenue;
	}
	/**
	 * Updates/sets the start time of the time slot
	 * @param newstartTime The start time of this time slot
	 */
	public void setstartTime(String newstartTime) {
		startTime = newstartTime;
	}
	/**
	 * Updates/sets the end time of the time slot
	 * @param newendTime The end time of this time slot
	 */
	public void setendTime(String newendTime) {
		endTime = newendTime;
	}
}
